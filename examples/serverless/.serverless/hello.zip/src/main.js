"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/tiny-json-http/bundle.js
var require_bundle = __commonJS({
  "node_modules/tiny-json-http/bundle.js"(exports2, module2) {
    !function(f) {
      if ("object" == typeof exports2 && "undefined" != typeof module2)
        module2.exports = f();
      else if ("function" == typeof define && define.amd)
        define([], f);
      else {
        ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).tiny = f();
      }
    }(function() {
      return function() {
        return function r(e, n, t) {
          function o(i2, f) {
            if (!n[i2]) {
              if (!e[i2]) {
                var c = "function" == typeof require && require;
                if (!f && c)
                  return c(i2, true);
                if (u)
                  return u(i2, true);
                var a = new Error("Cannot find module '" + i2 + "'");
                throw a.code = "MODULE_NOT_FOUND", a;
              }
              var p = n[i2] = { exports: {} };
              e[i2][0].call(p.exports, function(r2) {
                return o(e[i2][1][r2] || r2);
              }, p, p.exports, r, e, n, t);
            }
            return n[i2].exports;
          }
          for (var u = "function" == typeof require && require, i = 0; i < t.length; i++)
            o(t[i]);
          return o;
        };
      }()({ 1: [function(require2, module3, exports3) {
        var http = require2("http"), https = require2("https"), url = require2("url"), qs = require2("querystring");
        module3.exports = function(httpMethod, options, callback) {
          if ((options = JSON.parse(JSON.stringify(options))).body && !options.data && (options.data = options.body), !options.url)
            throw Error("options.url required");
          var promise;
          callback || (promise = new Promise(function(res, rej) {
            callback = function(err, result) {
              err ? rej(err) : res(result);
            };
          }));
          var opts = url.parse(options.url), method = "https:" === opts.protocol ? https.request : http.request;
          if (options.data) {
            var isSearch = !!opts.search;
            options.url += (isSearch ? "&" : "?") + qs.stringify(options.data), opts = url.parse(options.url);
          }
          options.timeout && (opts.timeout = options.timeout), opts.method = httpMethod, opts.headers = options.headers || {}, opts.headers["User-Agent"] = opts.headers["User-Agent"] || "tiny-http", opts.headers["Content-Type"] = opts.headers["Content-Type"] || "application/json; charset=utf-8";
          var req = method(opts, function(res) {
            var raw = [], ok = res.statusCode >= 200 && res.statusCode < 300;
            res.on("data", function(chunk) {
              raw.push(chunk);
            }), res.on("end", function() {
              var err = null, result = null, isJSON = res.headers["content-type"] && (res.headers["content-type"].startsWith("application/json") || res.headers["content-type"].match(/^application\/.*json/));
              try {
                if (result = Buffer.concat(raw), !options.buffer) {
                  var strRes = result.toString();
                  result = strRes && isJSON ? JSON.parse(strRes) : strRes;
                }
              } catch (e) {
                err = e;
              }
              ok ? callback(err, { body: result, headers: res.headers }) : ((err = Error("GET failed with: " + res.statusCode)).raw = res, err.body = isJSON ? JSON.stringify(result) : result.toString(), err.statusCode = res.statusCode, callback(err));
            });
          });
          return req.on("error", callback), req.end(), promise;
        };
      }, { http: void 0, https: void 0, querystring: void 0, url: void 0 }], 2: [function(require2, module3, exports3) {
        var qs = require2("querystring"), http = require2("http"), https = require2("https"), FormData = require2("@brianleroux/form-data"), url = require2("url");
        module3.exports = function(httpMethod, options, callback) {
          let formopts = options.data || options.body;
          if (formopts && false === Object.keys(formopts).some((k) => "string" != typeof formopts[k]) && (options = JSON.parse(JSON.stringify(options))), options.body && !options.data && (options.data = options.body), !options.url)
            throw Error("options.url required");
          var promise;
          callback || (promise = new Promise(function(res, rej) {
            callback = function(err, result) {
              err ? rej(err) : res(result);
            };
          }));
          var opts = url.parse(options.url), method = "https:" === opts.protocol ? https.request : http.request;
          options.timeout && (opts.timeout = timeout), opts.method = httpMethod, opts.headers = options.headers || {}, opts.headers["user-agent"] = opts.headers["user-agent"] || opts.headers["User-Agent"] || "tiny-http", opts.headers["content-type"] = opts.headers["content-type"] || opts.headers["Content-Type"] || "application/json; charset=utf-8";
          var postData = qs.stringify(options.data || {});
          function is(headers, type) {
            var regex = type instanceof RegExp, upper = headers["Content-Type"], lower = headers["content-type"], isU = upper && (regex ? upper.match(type) : upper.startsWith(type)), isL = lower && (regex ? lower.match(type) : lower.startsWith(type));
            return isU || isL;
          }
          is(opts.headers, /^application\/.*json/) && (postData = JSON.stringify(options.data || {})), is(opts.headers, "application/x-www-form-urlencoded") && (postData = Object.keys(options.data).map((k) => `${encodeURI(k)}=${encodeURI(options.data[k])}`).join("&")), opts.headers["Content-Length"] = Buffer.byteLength(postData);
          var isMultipart = is(opts.headers, "multipart/form-data");
          isMultipart && (method = function(params, streamback) {
            var form = new FormData();
            Object.keys(options.data).forEach((k) => {
              form.append(k, options.data[k]);
            }), delete opts.headers["Content-Type"], delete opts.headers["content-type"], delete opts.headers["Content-Length"], delete opts.headers["content-length"], form.submit(opts, function(err, res) {
              err ? callback(err) : streamback(res);
            });
          });
          var req = method(opts, function(res) {
            var raw = [], ok = res.statusCode >= 200 && res.statusCode < 300;
            res.on("data", function(chunk) {
              raw.push(chunk);
            }), res.on("end", function() {
              var err = null, result = null;
              try {
                if (result = Buffer.concat(raw), !options.buffer) {
                  var isJSON = is(res.headers, /^application\/.*json/), strRes = result.toString();
                  result = strRes && isJSON ? JSON.parse(strRes) : strRes;
                }
              } catch (e) {
                err = e;
              }
              ok ? callback(err, { body: result, headers: res.headers }) : ((err = Error(httpMethod + " failed with: " + res.statusCode)).raw = res, err.body = result, err.statusCode = res.statusCode, callback(err));
            });
          });
          return isMultipart || (req.on("error", callback), req.write(postData), req.end()), promise;
        };
      }, { "@brianleroux/form-data": 4, http: void 0, https: void 0, querystring: void 0, url: void 0 }], 3: [function(require2, module3, exports3) {
        var _read = require2("./_read"), _write = require2("./_write");
        module3.exports = { get: _read.bind({}, "GET"), head: _read.bind({}, "HEAD"), options: _read.bind({}, "OPTIONS"), post: _write.bind({}, "POST"), put: _write.bind({}, "PUT"), patch: _write.bind({}, "PATCH"), del: _write.bind({}, "DELETE"), delete: _write.bind({}, "DELETE") };
      }, { "./_read": 1, "./_write": 2 }], 4: [function(require2, module3, exports3) {
        var CombinedStream = require2("combined-stream"), util = require2("util"), path = require2("path"), http = require2("http"), https = require2("https"), parseUrl = require2("url").parse, fs = require2("fs"), mime = { lookup: require2("tiny-mime-lookup") }, asynckit = require2("asynckit"), populate = require2("./populate.js");
        function FormData(options) {
          if (!(this instanceof FormData))
            return new FormData();
          for (var option in this._overheadLength = 0, this._valueLength = 0, this._valuesToMeasure = [], CombinedStream.call(this), options = options || {})
            this[option] = options[option];
        }
        module3.exports = FormData, util.inherits(FormData, CombinedStream), FormData.LINE_BREAK = "\r\n", FormData.DEFAULT_CONTENT_TYPE = "application/octet-stream", FormData.prototype.append = function(field, value, options) {
          "string" == typeof (options = options || {}) && (options = { filename: options });
          var append = CombinedStream.prototype.append.bind(this);
          if ("number" == typeof value && (value = "" + value), util.isArray(value))
            this._error(new Error("Arrays are not supported."));
          else {
            var header = this._multiPartHeader(field, value, options), footer = this._multiPartFooter();
            append(header), append(value), append(footer), this._trackLength(header, value, options);
          }
        }, FormData.prototype._trackLength = function(header, value, options) {
          var valueLength = 0;
          null != options.knownLength ? valueLength += +options.knownLength : Buffer.isBuffer(value) ? valueLength = value.length : "string" == typeof value && (valueLength = Buffer.byteLength(value)), this._valueLength += valueLength, this._overheadLength += Buffer.byteLength(header) + FormData.LINE_BREAK.length, value && (value.path || value.readable && value.hasOwnProperty("httpVersion")) && (options.knownLength || this._valuesToMeasure.push(value));
        }, FormData.prototype._lengthRetriever = function(value, callback) {
          value.hasOwnProperty("fd") ? void 0 != value.end && value.end != 1 / 0 && void 0 != value.start ? callback(null, value.end + 1 - (value.start ? value.start : 0)) : fs.stat(value.path, function(err, stat) {
            var fileSize;
            err ? callback(err) : (fileSize = stat.size - (value.start ? value.start : 0), callback(null, fileSize));
          }) : value.hasOwnProperty("httpVersion") ? callback(null, +value.headers["content-length"]) : value.hasOwnProperty("httpModule") ? (value.on("response", function(response) {
            value.pause(), callback(null, +response.headers["content-length"]);
          }), value.resume()) : callback("Unknown stream");
        }, FormData.prototype._multiPartHeader = function(field, value, options) {
          if ("string" == typeof options.header)
            return options.header;
          var header, contentDisposition = this._getContentDisposition(value, options), contentType = this._getContentType(value, options), contents = "", headers = { "Content-Disposition": ["form-data", 'name="' + field + '"'].concat(contentDisposition || []), "Content-Type": [].concat(contentType || []) };
          for (var prop in "object" == typeof options.header && populate(headers, options.header), headers)
            headers.hasOwnProperty(prop) && null != (header = headers[prop]) && (Array.isArray(header) || (header = [header]), header.length && (contents += prop + ": " + header.join("; ") + FormData.LINE_BREAK));
          return "--" + this.getBoundary() + FormData.LINE_BREAK + contents + FormData.LINE_BREAK;
        }, FormData.prototype._getContentDisposition = function(value, options) {
          var filename, contentDisposition;
          return "string" == typeof options.filepath ? filename = path.normalize(options.filepath).replace(/\\/g, "/") : options.filename || value.name || value.path ? filename = path.basename(options.filename || value.name || value.path) : value.readable && value.hasOwnProperty("httpVersion") && (filename = path.basename(value.client._httpMessage.path)), filename && (contentDisposition = 'filename="' + filename + '"'), contentDisposition;
        }, FormData.prototype._getContentType = function(value, options) {
          var contentType = options.contentType;
          return !contentType && value.name && (contentType = mime.lookup(value.name)), !contentType && value.path && (contentType = mime.lookup(value.path)), !contentType && value.readable && value.hasOwnProperty("httpVersion") && (contentType = value.headers["content-type"]), contentType || !options.filepath && !options.filename || (contentType = mime.lookup(options.filepath || options.filename)), contentType || "object" != typeof value || (contentType = FormData.DEFAULT_CONTENT_TYPE), contentType;
        }, FormData.prototype._multiPartFooter = function() {
          return function(next) {
            var footer = FormData.LINE_BREAK;
            0 === this._streams.length && (footer += this._lastBoundary()), next(footer);
          }.bind(this);
        }, FormData.prototype._lastBoundary = function() {
          return "--" + this.getBoundary() + "--" + FormData.LINE_BREAK;
        }, FormData.prototype.getHeaders = function(userHeaders) {
          var header, formHeaders = { "content-type": "multipart/form-data; boundary=" + this.getBoundary() };
          for (header in userHeaders)
            userHeaders.hasOwnProperty(header) && (formHeaders[header.toLowerCase()] = userHeaders[header]);
          return formHeaders;
        }, FormData.prototype.getBoundary = function() {
          return this._boundary || this._generateBoundary(), this._boundary;
        }, FormData.prototype._generateBoundary = function() {
          for (var boundary = "--------------------------", i = 0; i < 24; i++)
            boundary += Math.floor(10 * Math.random()).toString(16);
          this._boundary = boundary;
        }, FormData.prototype.getLengthSync = function() {
          var knownLength = this._overheadLength + this._valueLength;
          return this._streams.length && (knownLength += this._lastBoundary().length), this.hasKnownLength() || this._error(new Error("Cannot calculate proper length in synchronous way.")), knownLength;
        }, FormData.prototype.hasKnownLength = function() {
          var hasKnownLength = true;
          return this._valuesToMeasure.length && (hasKnownLength = false), hasKnownLength;
        }, FormData.prototype.getLength = function(cb) {
          var knownLength = this._overheadLength + this._valueLength;
          this._streams.length && (knownLength += this._lastBoundary().length), this._valuesToMeasure.length ? asynckit.parallel(this._valuesToMeasure, this._lengthRetriever, function(err, values) {
            err ? cb(err) : (values.forEach(function(length) {
              knownLength += length;
            }), cb(null, knownLength));
          }) : process.nextTick(cb.bind(this, null, knownLength));
        }, FormData.prototype.submit = function(params, cb) {
          var request, options, defaults = { method: "post" };
          return "string" == typeof params ? (params = parseUrl(params), options = populate({ port: params.port, path: params.pathname, host: params.hostname, protocol: params.protocol }, defaults)) : (options = populate(params, defaults)).port || (options.port = "https:" == options.protocol ? 443 : 80), options.headers = this.getHeaders(params.headers), request = "https:" == options.protocol ? https.request(options) : http.request(options), this.getLength(function(err, length) {
            err ? this._error(err) : (request.setHeader("Content-Length", length), this.pipe(request), cb && (request.on("error", cb), request.on("response", cb.bind(this, null))));
          }.bind(this)), request;
        }, FormData.prototype._error = function(err) {
          this.error || (this.error = err, this.pause(), this.emit("error", err));
        }, FormData.prototype.toString = function() {
          return "[object FormData]";
        };
      }, { "./populate.js": 5, asynckit: 6, "combined-stream": 16, fs: void 0, http: void 0, https: void 0, path: void 0, "tiny-mime-lookup": 18, url: void 0, util: void 0 }], 5: [function(require2, module3, exports3) {
        module3.exports = function(dst, src) {
          return Object.keys(src).forEach(function(prop) {
            dst[prop] = dst[prop] || src[prop];
          }), dst;
        };
      }, {}], 6: [function(require2, module3, exports3) {
        module3.exports = { parallel: require2("./parallel.js"), serial: require2("./serial.js"), serialOrdered: require2("./serialOrdered.js") };
      }, { "./parallel.js": 13, "./serial.js": 14, "./serialOrdered.js": 15 }], 7: [function(require2, module3, exports3) {
        module3.exports = function(state) {
          Object.keys(state.jobs).forEach(function(key) {
            "function" == typeof this.jobs[key] && this.jobs[key]();
          }.bind(state)), state.jobs = {};
        };
      }, {}], 8: [function(require2, module3, exports3) {
        var defer = require2("./defer.js");
        module3.exports = function(callback) {
          var isAsync = false;
          return defer(function() {
            isAsync = true;
          }), function(err, result) {
            isAsync ? callback(err, result) : defer(function() {
              callback(err, result);
            });
          };
        };
      }, { "./defer.js": 9 }], 9: [function(require2, module3, exports3) {
        module3.exports = function(fn) {
          var nextTick = "function" == typeof setImmediate ? setImmediate : "object" == typeof process && "function" == typeof process.nextTick ? process.nextTick : null;
          nextTick ? nextTick(fn) : setTimeout(fn, 0);
        };
      }, {}], 10: [function(require2, module3, exports3) {
        var async = require2("./async.js"), abort = require2("./abort.js");
        module3.exports = function(list, iterator, state, callback) {
          var key = state.keyedList ? state.keyedList[state.index] : state.index;
          state.jobs[key] = function(iterator2, key2, item, callback2) {
            var aborter;
            aborter = 2 == iterator2.length ? iterator2(item, async(callback2)) : iterator2(item, key2, async(callback2));
            return aborter;
          }(iterator, key, list[key], function(error, output) {
            key in state.jobs && (delete state.jobs[key], error ? abort(state) : state.results[key] = output, callback(error, state.results));
          });
        };
      }, { "./abort.js": 7, "./async.js": 8 }], 11: [function(require2, module3, exports3) {
        module3.exports = function(list, sortMethod) {
          var isNamedList = !Array.isArray(list), initState = { index: 0, keyedList: isNamedList || sortMethod ? Object.keys(list) : null, jobs: {}, results: isNamedList ? {} : [], size: isNamedList ? Object.keys(list).length : list.length };
          sortMethod && initState.keyedList.sort(isNamedList ? sortMethod : function(a, b) {
            return sortMethod(list[a], list[b]);
          });
          return initState;
        };
      }, {}], 12: [function(require2, module3, exports3) {
        var abort = require2("./abort.js"), async = require2("./async.js");
        module3.exports = function(callback) {
          if (!Object.keys(this.jobs).length)
            return;
          this.index = this.size, abort(this), async(callback)(null, this.results);
        };
      }, { "./abort.js": 7, "./async.js": 8 }], 13: [function(require2, module3, exports3) {
        var iterate = require2("./lib/iterate.js"), initState = require2("./lib/state.js"), terminator = require2("./lib/terminator.js");
        module3.exports = function(list, iterator, callback) {
          var state = initState(list);
          for (; state.index < (state.keyedList || list).length; )
            iterate(list, iterator, state, function(error, result) {
              error ? callback(error, result) : 0 !== Object.keys(state.jobs).length || callback(null, state.results);
            }), state.index++;
          return terminator.bind(state, callback);
        };
      }, { "./lib/iterate.js": 10, "./lib/state.js": 11, "./lib/terminator.js": 12 }], 14: [function(require2, module3, exports3) {
        var serialOrdered = require2("./serialOrdered.js");
        module3.exports = function(list, iterator, callback) {
          return serialOrdered(list, iterator, null, callback);
        };
      }, { "./serialOrdered.js": 15 }], 15: [function(require2, module3, exports3) {
        var iterate = require2("./lib/iterate.js"), initState = require2("./lib/state.js"), terminator = require2("./lib/terminator.js");
        function ascending(a, b) {
          return a < b ? -1 : a > b ? 1 : 0;
        }
        module3.exports = function(list, iterator, sortMethod, callback) {
          var state = initState(list, sortMethod);
          return iterate(list, iterator, state, function iteratorHandler(error, result) {
            error ? callback(error, result) : (state.index++, state.index < (state.keyedList || list).length ? iterate(list, iterator, state, iteratorHandler) : callback(null, state.results));
          }), terminator.bind(state, callback);
        }, module3.exports.ascending = ascending, module3.exports.descending = function(a, b) {
          return -1 * ascending(a, b);
        };
      }, { "./lib/iterate.js": 10, "./lib/state.js": 11, "./lib/terminator.js": 12 }], 16: [function(require2, module3, exports3) {
        var util = require2("util"), Stream = require2("stream").Stream, DelayedStream = require2("delayed-stream");
        function CombinedStream() {
          this.writable = false, this.readable = true, this.dataSize = 0, this.maxDataSize = 2097152, this.pauseStreams = true, this._released = false, this._streams = [], this._currentStream = null, this._insideLoop = false, this._pendingNext = false;
        }
        module3.exports = CombinedStream, util.inherits(CombinedStream, Stream), CombinedStream.create = function(options) {
          var combinedStream = new this();
          for (var option in options = options || {})
            combinedStream[option] = options[option];
          return combinedStream;
        }, CombinedStream.isStreamLike = function(stream) {
          return "function" != typeof stream && "string" != typeof stream && "boolean" != typeof stream && "number" != typeof stream && !Buffer.isBuffer(stream);
        }, CombinedStream.prototype.append = function(stream) {
          if (CombinedStream.isStreamLike(stream)) {
            if (!(stream instanceof DelayedStream)) {
              var newStream = DelayedStream.create(stream, { maxDataSize: 1 / 0, pauseStream: this.pauseStreams });
              stream.on("data", this._checkDataSize.bind(this)), stream = newStream;
            }
            this._handleErrors(stream), this.pauseStreams && stream.pause();
          }
          return this._streams.push(stream), this;
        }, CombinedStream.prototype.pipe = function(dest, options) {
          return Stream.prototype.pipe.call(this, dest, options), this.resume(), dest;
        }, CombinedStream.prototype._getNext = function() {
          if (this._currentStream = null, this._insideLoop)
            this._pendingNext = true;
          else {
            this._insideLoop = true;
            try {
              do {
                this._pendingNext = false, this._realGetNext();
              } while (this._pendingNext);
            } finally {
              this._insideLoop = false;
            }
          }
        }, CombinedStream.prototype._realGetNext = function() {
          var stream = this._streams.shift();
          void 0 !== stream ? "function" == typeof stream ? stream(function(stream2) {
            CombinedStream.isStreamLike(stream2) && (stream2.on("data", this._checkDataSize.bind(this)), this._handleErrors(stream2)), this._pipeNext(stream2);
          }.bind(this)) : this._pipeNext(stream) : this.end();
        }, CombinedStream.prototype._pipeNext = function(stream) {
          if (this._currentStream = stream, CombinedStream.isStreamLike(stream))
            return stream.on("end", this._getNext.bind(this)), void stream.pipe(this, { end: false });
          var value = stream;
          this.write(value), this._getNext();
        }, CombinedStream.prototype._handleErrors = function(stream) {
          var self2 = this;
          stream.on("error", function(err) {
            self2._emitError(err);
          });
        }, CombinedStream.prototype.write = function(data) {
          this.emit("data", data);
        }, CombinedStream.prototype.pause = function() {
          this.pauseStreams && (this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.pause && this._currentStream.pause(), this.emit("pause"));
        }, CombinedStream.prototype.resume = function() {
          this._released || (this._released = true, this.writable = true, this._getNext()), this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.resume && this._currentStream.resume(), this.emit("resume");
        }, CombinedStream.prototype.end = function() {
          this._reset(), this.emit("end");
        }, CombinedStream.prototype.destroy = function() {
          this._reset(), this.emit("close");
        }, CombinedStream.prototype._reset = function() {
          this.writable = false, this._streams = [], this._currentStream = null;
        }, CombinedStream.prototype._checkDataSize = function() {
          if (this._updateDataSize(), !(this.dataSize <= this.maxDataSize)) {
            var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
            this._emitError(new Error(message));
          }
        }, CombinedStream.prototype._updateDataSize = function() {
          this.dataSize = 0;
          var self2 = this;
          this._streams.forEach(function(stream) {
            stream.dataSize && (self2.dataSize += stream.dataSize);
          }), this._currentStream && this._currentStream.dataSize && (this.dataSize += this._currentStream.dataSize);
        }, CombinedStream.prototype._emitError = function(err) {
          this._reset(), this.emit("error", err);
        };
      }, { "delayed-stream": 17, stream: void 0, util: void 0 }], 17: [function(require2, module3, exports3) {
        var Stream = require2("stream").Stream, util = require2("util");
        function DelayedStream() {
          this.source = null, this.dataSize = 0, this.maxDataSize = 1048576, this.pauseStream = true, this._maxDataSizeExceeded = false, this._released = false, this._bufferedEvents = [];
        }
        module3.exports = DelayedStream, util.inherits(DelayedStream, Stream), DelayedStream.create = function(source, options) {
          var delayedStream = new this();
          for (var option in options = options || {})
            delayedStream[option] = options[option];
          delayedStream.source = source;
          var realEmit = source.emit;
          return source.emit = function() {
            return delayedStream._handleEmit(arguments), realEmit.apply(source, arguments);
          }, source.on("error", function() {
          }), delayedStream.pauseStream && source.pause(), delayedStream;
        }, Object.defineProperty(DelayedStream.prototype, "readable", { configurable: true, enumerable: true, get: function() {
          return this.source.readable;
        } }), DelayedStream.prototype.setEncoding = function() {
          return this.source.setEncoding.apply(this.source, arguments);
        }, DelayedStream.prototype.resume = function() {
          this._released || this.release(), this.source.resume();
        }, DelayedStream.prototype.pause = function() {
          this.source.pause();
        }, DelayedStream.prototype.release = function() {
          this._released = true, this._bufferedEvents.forEach(function(args) {
            this.emit.apply(this, args);
          }.bind(this)), this._bufferedEvents = [];
        }, DelayedStream.prototype.pipe = function() {
          var r = Stream.prototype.pipe.apply(this, arguments);
          return this.resume(), r;
        }, DelayedStream.prototype._handleEmit = function(args) {
          this._released ? this.emit.apply(this, args) : ("data" === args[0] && (this.dataSize += args[1].length, this._checkIfMaxDataSizeExceeded()), this._bufferedEvents.push(args));
        }, DelayedStream.prototype._checkIfMaxDataSizeExceeded = function() {
          if (!(this._maxDataSizeExceeded || this.dataSize <= this.maxDataSize)) {
            this._maxDataSizeExceeded = true;
            var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
            this.emit("error", new Error(message));
          }
        };
      }, { stream: void 0, util: void 0 }], 18: [function(require2, module3, exports3) {
        var types = require2("./types"), extname = require2("path").extname, db = {};
        Object.keys(types).forEach((mime) => {
          types[mime].forEach((extn) => {
            db[extn] = mime;
          });
        }), module3.exports = function(path) {
          if (!path || "string" != typeof path)
            return false;
          var extension = extname("x." + path).toLowerCase().substr(1);
          return extension && db[extension] || false;
        };
      }, { "./types": 19, path: void 0 }], 19: [function(require2, module3, exports3) {
        module3.exports = { "application/andrew-inset": ["ez"], "application/applixware": ["aw"], "application/atom+xml": ["atom"], "application/atomcat+xml": ["atomcat"], "application/atomsvc+xml": ["atomsvc"], "application/bdoc": ["bdoc"], "application/ccxml+xml": ["ccxml"], "application/cdmi-capability": ["cdmia"], "application/cdmi-container": ["cdmic"], "application/cdmi-domain": ["cdmid"], "application/cdmi-object": ["cdmio"], "application/cdmi-queue": ["cdmiq"], "application/cu-seeme": ["cu"], "application/dash+xml": ["mpd"], "application/davmount+xml": ["davmount"], "application/docbook+xml": ["dbk"], "application/dssc+der": ["dssc"], "application/dssc+xml": ["xdssc"], "application/ecmascript": ["ecma"], "application/emma+xml": ["emma"], "application/epub+zip": ["epub"], "application/exi": ["exi"], "application/font-tdpfr": ["pfr"], "application/font-woff": ["woff"], "application/font-woff2": ["*woff2"], "application/geo+json": ["geojson"], "application/gml+xml": ["gml"], "application/gpx+xml": ["gpx"], "application/gxf": ["gxf"], "application/gzip": ["gz"], "application/hjson": ["hjson"], "application/hyperstudio": ["stk"], "application/inkml+xml": ["ink", "inkml"], "application/ipfix": ["ipfix"], "application/java-archive": ["jar", "war", "ear"], "application/java-serialized-object": ["ser"], "application/java-vm": ["class"], "application/javascript": ["js", "mjs"], "application/json": ["json", "map"], "application/json5": ["json5"], "application/jsonml+json": ["jsonml"], "application/ld+json": ["jsonld"], "application/lost+xml": ["lostxml"], "application/mac-binhex40": ["hqx"], "application/mac-compactpro": ["cpt"], "application/mads+xml": ["mads"], "application/manifest+json": ["webmanifest"], "application/marc": ["mrc"], "application/marcxml+xml": ["mrcx"], "application/mathematica": ["ma", "nb", "mb"], "application/mathml+xml": ["mathml"], "application/mbox": ["mbox"], "application/mediaservercontrol+xml": ["mscml"], "application/metalink+xml": ["metalink"], "application/metalink4+xml": ["meta4"], "application/mets+xml": ["mets"], "application/mods+xml": ["mods"], "application/mp21": ["m21", "mp21"], "application/mp4": ["mp4s", "m4p"], "application/msword": ["doc", "dot"], "application/mxf": ["mxf"], "application/octet-stream": ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"], "application/oda": ["oda"], "application/oebps-package+xml": ["opf"], "application/ogg": ["ogx"], "application/omdoc+xml": ["omdoc"], "application/onenote": ["onetoc", "onetoc2", "onetmp", "onepkg"], "application/oxps": ["oxps"], "application/patch-ops-error+xml": ["xer"], "application/pdf": ["pdf"], "application/pgp-encrypted": ["pgp"], "application/pgp-signature": ["asc", "sig"], "application/pics-rules": ["prf"], "application/pkcs10": ["p10"], "application/pkcs7-mime": ["p7m", "p7c"], "application/pkcs7-signature": ["p7s"], "application/pkcs8": ["p8"], "application/pkix-attr-cert": ["ac"], "application/pkix-cert": ["cer"], "application/pkix-crl": ["crl"], "application/pkix-pkipath": ["pkipath"], "application/pkixcmp": ["pki"], "application/pls+xml": ["pls"], "application/postscript": ["ai", "eps", "ps"], "application/pskc+xml": ["pskcxml"], "application/raml+yaml": ["raml"], "application/rdf+xml": ["rdf"], "application/reginfo+xml": ["rif"], "application/relax-ng-compact-syntax": ["rnc"], "application/resource-lists+xml": ["rl"], "application/resource-lists-diff+xml": ["rld"], "application/rls-services+xml": ["rs"], "application/rpki-ghostbusters": ["gbr"], "application/rpki-manifest": ["mft"], "application/rpki-roa": ["roa"], "application/rsd+xml": ["rsd"], "application/rss+xml": ["rss"], "application/rtf": ["rtf"], "application/sbml+xml": ["sbml"], "application/scvp-cv-request": ["scq"], "application/scvp-cv-response": ["scs"], "application/scvp-vp-request": ["spq"], "application/scvp-vp-response": ["spp"], "application/sdp": ["sdp"], "application/set-payment-initiation": ["setpay"], "application/set-registration-initiation": ["setreg"], "application/shf+xml": ["shf"], "application/smil+xml": ["smi", "smil"], "application/sparql-query": ["rq"], "application/sparql-results+xml": ["srx"], "application/srgs": ["gram"], "application/srgs+xml": ["grxml"], "application/sru+xml": ["sru"], "application/ssdl+xml": ["ssdl"], "application/ssml+xml": ["ssml"], "application/tei+xml": ["tei", "teicorpus"], "application/thraud+xml": ["tfi"], "application/timestamped-data": ["tsd"], "application/voicexml+xml": ["vxml"], "application/wasm": ["wasm"], "application/widget": ["wgt"], "application/winhlp": ["hlp"], "application/wsdl+xml": ["wsdl"], "application/wspolicy+xml": ["wspolicy"], "application/xaml+xml": ["xaml"], "application/xcap-diff+xml": ["xdf"], "application/xenc+xml": ["xenc"], "application/xhtml+xml": ["xhtml", "xht"], "application/xml": ["xml", "xsl", "xsd", "rng"], "application/xml-dtd": ["dtd"], "application/xop+xml": ["xop"], "application/xproc+xml": ["xpl"], "application/xslt+xml": ["xslt"], "application/xspf+xml": ["xspf"], "application/xv+xml": ["mxml", "xhvml", "xvml", "xvm"], "application/yang": ["yang"], "application/yin+xml": ["yin"], "application/zip": ["zip"], "audio/3gpp": ["*3gpp"], "audio/adpcm": ["adp"], "audio/basic": ["au", "snd"], "audio/midi": ["mid", "midi", "kar", "rmi"], "audio/mp3": ["*mp3"], "audio/mp4": ["m4a", "mp4a"], "audio/mpeg": ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"], "audio/ogg": ["oga", "ogg", "spx"], "audio/s3m": ["s3m"], "audio/silk": ["sil"], "audio/wav": ["wav"], "audio/wave": ["*wav"], "audio/webm": ["weba"], "audio/xm": ["xm"], "font/collection": ["ttc"], "font/otf": ["otf"], "font/ttf": ["ttf"], "font/woff": ["*woff"], "font/woff2": ["woff2"], "image/apng": ["apng"], "image/bmp": ["bmp"], "image/cgm": ["cgm"], "image/g3fax": ["g3"], "image/gif": ["gif"], "image/ief": ["ief"], "image/jp2": ["jp2", "jpg2"], "image/jpeg": ["jpeg", "jpg", "jpe"], "image/jpm": ["jpm"], "image/jpx": ["jpx", "jpf"], "image/ktx": ["ktx"], "image/png": ["png"], "image/sgi": ["sgi"], "image/svg+xml": ["svg", "svgz"], "image/tiff": ["tiff", "tif"], "image/webp": ["webp"], "message/rfc822": ["eml", "mime"], "model/gltf+json": ["gltf"], "model/gltf-binary": ["glb"], "model/iges": ["igs", "iges"], "model/mesh": ["msh", "mesh", "silo"], "model/vrml": ["wrl", "vrml"], "model/x3d+binary": ["x3db", "x3dbz"], "model/x3d+vrml": ["x3dv", "x3dvz"], "model/x3d+xml": ["x3d", "x3dz"], "text/cache-manifest": ["appcache", "manifest"], "text/calendar": ["ics", "ifb"], "text/coffeescript": ["coffee", "litcoffee"], "text/css": ["css"], "text/csv": ["csv"], "text/html": ["html", "htm", "shtml"], "text/jade": ["jade"], "text/jsx": ["jsx"], "text/less": ["less"], "text/markdown": ["markdown", "md"], "text/mathml": ["mml"], "text/n3": ["n3"], "text/plain": ["txt", "text", "conf", "def", "list", "log", "in", "ini"], "text/richtext": ["rtx"], "text/rtf": ["*rtf"], "text/sgml": ["sgml", "sgm"], "text/shex": ["shex"], "text/slim": ["slim", "slm"], "text/stylus": ["stylus", "styl"], "text/tab-separated-values": ["tsv"], "text/troff": ["t", "tr", "roff", "man", "me", "ms"], "text/turtle": ["ttl"], "text/uri-list": ["uri", "uris", "urls"], "text/vcard": ["vcard"], "text/vtt": ["vtt"], "text/xml": ["*xml"], "text/yaml": ["yaml", "yml"], "video/3gpp": ["3gp", "3gpp"], "video/3gpp2": ["3g2"], "video/h261": ["h261"], "video/h263": ["h263"], "video/h264": ["h264"], "video/jpeg": ["jpgv"], "video/jpm": ["*jpm", "jpgm"], "video/mj2": ["mj2", "mjp2"], "video/mp2t": ["ts"], "video/mp4": ["mp4", "mp4v", "mpg4"], "video/mpeg": ["mpeg", "mpg", "mpe", "m1v", "m2v"], "video/ogg": ["ogv"], "video/quicktime": ["qt", "mov"], "video/webm": ["webm"] };
      }, {}] }, {}, [3])(3);
    });
  }
});

// node_modules/@opentelemetry/api/build/src/platform/node/globalThis.js
var require_globalThis = __commonJS({
  "node_modules/@opentelemetry/api/build/src/platform/node/globalThis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._globalThis = void 0;
    exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
  }
});

// node_modules/@opentelemetry/api/build/src/platform/node/index.js
var require_node = __commonJS({
  "node_modules/@opentelemetry/api/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_globalThis(), exports2);
  }
});

// node_modules/@opentelemetry/api/build/src/platform/index.js
var require_platform = __commonJS({
  "node_modules/@opentelemetry/api/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node(), exports2);
  }
});

// node_modules/@opentelemetry/api/build/src/version.js
var require_version = __commonJS({
  "node_modules/@opentelemetry/api/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "1.3.0";
  }
});

// node_modules/@opentelemetry/api/build/src/internal/semver.js
var require_semver = __commonJS({
  "node_modules/@opentelemetry/api/build/src/internal/semver.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isCompatible = exports2._makeCompatibilityCheck = void 0;
    var version_1 = require_version();
    var re = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
    function _makeCompatibilityCheck(ownVersion) {
      const acceptedVersions = /* @__PURE__ */ new Set([ownVersion]);
      const rejectedVersions = /* @__PURE__ */ new Set();
      const myVersionMatch = ownVersion.match(re);
      if (!myVersionMatch) {
        return () => false;
      }
      const ownVersionParsed = {
        major: +myVersionMatch[1],
        minor: +myVersionMatch[2],
        patch: +myVersionMatch[3],
        prerelease: myVersionMatch[4]
      };
      if (ownVersionParsed.prerelease != null) {
        return function isExactmatch(globalVersion) {
          return globalVersion === ownVersion;
        };
      }
      function _reject(v) {
        rejectedVersions.add(v);
        return false;
      }
      function _accept(v) {
        acceptedVersions.add(v);
        return true;
      }
      return function isCompatible(globalVersion) {
        if (acceptedVersions.has(globalVersion)) {
          return true;
        }
        if (rejectedVersions.has(globalVersion)) {
          return false;
        }
        const globalVersionMatch = globalVersion.match(re);
        if (!globalVersionMatch) {
          return _reject(globalVersion);
        }
        const globalVersionParsed = {
          major: +globalVersionMatch[1],
          minor: +globalVersionMatch[2],
          patch: +globalVersionMatch[3],
          prerelease: globalVersionMatch[4]
        };
        if (globalVersionParsed.prerelease != null) {
          return _reject(globalVersion);
        }
        if (ownVersionParsed.major !== globalVersionParsed.major) {
          return _reject(globalVersion);
        }
        if (ownVersionParsed.major === 0) {
          if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) {
            return _accept(globalVersion);
          }
          return _reject(globalVersion);
        }
        if (ownVersionParsed.minor <= globalVersionParsed.minor) {
          return _accept(globalVersion);
        }
        return _reject(globalVersion);
      };
    }
    exports2._makeCompatibilityCheck = _makeCompatibilityCheck;
    exports2.isCompatible = _makeCompatibilityCheck(version_1.VERSION);
  }
});

// node_modules/@opentelemetry/api/build/src/internal/global-utils.js
var require_global_utils = __commonJS({
  "node_modules/@opentelemetry/api/build/src/internal/global-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unregisterGlobal = exports2.getGlobal = exports2.registerGlobal = void 0;
    var platform_1 = require_platform();
    var version_1 = require_version();
    var semver_1 = require_semver();
    var major = version_1.VERSION.split(".")[0];
    var GLOBAL_OPENTELEMETRY_API_KEY = Symbol.for(`opentelemetry.js.api.${major}`);
    var _global = platform_1._globalThis;
    function registerGlobal(type, instance, diag, allowOverride = false) {
      var _a;
      const api = _global[GLOBAL_OPENTELEMETRY_API_KEY] = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) !== null && _a !== void 0 ? _a : {
        version: version_1.VERSION
      };
      if (!allowOverride && api[type]) {
        const err = new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${type}`);
        diag.error(err.stack || err.message);
        return false;
      }
      if (api.version !== version_1.VERSION) {
        const err = new Error("@opentelemetry/api: All API registration versions must match");
        diag.error(err.stack || err.message);
        return false;
      }
      api[type] = instance;
      diag.debug(`@opentelemetry/api: Registered a global for ${type} v${version_1.VERSION}.`);
      return true;
    }
    exports2.registerGlobal = registerGlobal;
    function getGlobal(type) {
      var _a, _b;
      const globalVersion = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _a === void 0 ? void 0 : _a.version;
      if (!globalVersion || !(0, semver_1.isCompatible)(globalVersion)) {
        return;
      }
      return (_b = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _b === void 0 ? void 0 : _b[type];
    }
    exports2.getGlobal = getGlobal;
    function unregisterGlobal(type, diag) {
      diag.debug(`@opentelemetry/api: Unregistering a global for ${type} v${version_1.VERSION}.`);
      const api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
      if (api) {
        delete api[type];
      }
    }
    exports2.unregisterGlobal = unregisterGlobal;
  }
});

// node_modules/@opentelemetry/api/build/src/diag/ComponentLogger.js
var require_ComponentLogger = __commonJS({
  "node_modules/@opentelemetry/api/build/src/diag/ComponentLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagComponentLogger = void 0;
    var global_utils_1 = require_global_utils();
    var DiagComponentLogger = class {
      constructor(props) {
        this._namespace = props.namespace || "DiagComponentLogger";
      }
      debug(...args) {
        return logProxy("debug", this._namespace, args);
      }
      error(...args) {
        return logProxy("error", this._namespace, args);
      }
      info(...args) {
        return logProxy("info", this._namespace, args);
      }
      warn(...args) {
        return logProxy("warn", this._namespace, args);
      }
      verbose(...args) {
        return logProxy("verbose", this._namespace, args);
      }
    };
    exports2.DiagComponentLogger = DiagComponentLogger;
    function logProxy(funcName, namespace, args) {
      const logger = (0, global_utils_1.getGlobal)("diag");
      if (!logger) {
        return;
      }
      args.unshift(namespace);
      return logger[funcName](...args);
    }
  }
});

// node_modules/@opentelemetry/api/build/src/diag/types.js
var require_types = __commonJS({
  "node_modules/@opentelemetry/api/build/src/diag/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagLogLevel = void 0;
    var DiagLogLevel;
    (function(DiagLogLevel2) {
      DiagLogLevel2[DiagLogLevel2["NONE"] = 0] = "NONE";
      DiagLogLevel2[DiagLogLevel2["ERROR"] = 30] = "ERROR";
      DiagLogLevel2[DiagLogLevel2["WARN"] = 50] = "WARN";
      DiagLogLevel2[DiagLogLevel2["INFO"] = 60] = "INFO";
      DiagLogLevel2[DiagLogLevel2["DEBUG"] = 70] = "DEBUG";
      DiagLogLevel2[DiagLogLevel2["VERBOSE"] = 80] = "VERBOSE";
      DiagLogLevel2[DiagLogLevel2["ALL"] = 9999] = "ALL";
    })(DiagLogLevel = exports2.DiagLogLevel || (exports2.DiagLogLevel = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js
var require_logLevelLogger = __commonJS({
  "node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createLogLevelDiagLogger = void 0;
    var types_1 = require_types();
    function createLogLevelDiagLogger(maxLevel, logger) {
      if (maxLevel < types_1.DiagLogLevel.NONE) {
        maxLevel = types_1.DiagLogLevel.NONE;
      } else if (maxLevel > types_1.DiagLogLevel.ALL) {
        maxLevel = types_1.DiagLogLevel.ALL;
      }
      logger = logger || {};
      function _filterFunc(funcName, theLevel) {
        const theFunc = logger[funcName];
        if (typeof theFunc === "function" && maxLevel >= theLevel) {
          return theFunc.bind(logger);
        }
        return function() {
        };
      }
      return {
        error: _filterFunc("error", types_1.DiagLogLevel.ERROR),
        warn: _filterFunc("warn", types_1.DiagLogLevel.WARN),
        info: _filterFunc("info", types_1.DiagLogLevel.INFO),
        debug: _filterFunc("debug", types_1.DiagLogLevel.DEBUG),
        verbose: _filterFunc("verbose", types_1.DiagLogLevel.VERBOSE)
      };
    }
    exports2.createLogLevelDiagLogger = createLogLevelDiagLogger;
  }
});

// node_modules/@opentelemetry/api/build/src/api/diag.js
var require_diag = __commonJS({
  "node_modules/@opentelemetry/api/build/src/api/diag.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagAPI = void 0;
    var ComponentLogger_1 = require_ComponentLogger();
    var logLevelLogger_1 = require_logLevelLogger();
    var types_1 = require_types();
    var global_utils_1 = require_global_utils();
    var API_NAME = "diag";
    var DiagAPI = class {
      /**
       * Private internal constructor
       * @private
       */
      constructor() {
        function _logProxy(funcName) {
          return function(...args) {
            const logger = (0, global_utils_1.getGlobal)("diag");
            if (!logger)
              return;
            return logger[funcName](...args);
          };
        }
        const self2 = this;
        const setLogger = (logger, optionsOrLogLevel = { logLevel: types_1.DiagLogLevel.INFO }) => {
          var _a, _b, _c;
          if (logger === self2) {
            const err = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
            self2.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
            return false;
          }
          if (typeof optionsOrLogLevel === "number") {
            optionsOrLogLevel = {
              logLevel: optionsOrLogLevel
            };
          }
          const oldLogger = (0, global_utils_1.getGlobal)("diag");
          const newLogger = (0, logLevelLogger_1.createLogLevelDiagLogger)((_b = optionsOrLogLevel.logLevel) !== null && _b !== void 0 ? _b : types_1.DiagLogLevel.INFO, logger);
          if (oldLogger && !optionsOrLogLevel.suppressOverrideMessage) {
            const stack = (_c = new Error().stack) !== null && _c !== void 0 ? _c : "<failed to generate stacktrace>";
            oldLogger.warn(`Current logger will be overwritten from ${stack}`);
            newLogger.warn(`Current logger will overwrite one already registered from ${stack}`);
          }
          return (0, global_utils_1.registerGlobal)("diag", newLogger, self2, true);
        };
        self2.setLogger = setLogger;
        self2.disable = () => {
          (0, global_utils_1.unregisterGlobal)(API_NAME, self2);
        };
        self2.createComponentLogger = (options) => {
          return new ComponentLogger_1.DiagComponentLogger(options);
        };
        self2.verbose = _logProxy("verbose");
        self2.debug = _logProxy("debug");
        self2.info = _logProxy("info");
        self2.warn = _logProxy("warn");
        self2.error = _logProxy("error");
      }
      /** Get the singleton instance of the DiagAPI API */
      static instance() {
        if (!this._instance) {
          this._instance = new DiagAPI();
        }
        return this._instance;
      }
    };
    exports2.DiagAPI = DiagAPI;
  }
});

// node_modules/@opentelemetry/api/build/src/baggage/internal/baggage-impl.js
var require_baggage_impl = __commonJS({
  "node_modules/@opentelemetry/api/build/src/baggage/internal/baggage-impl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BaggageImpl = void 0;
    var BaggageImpl = class {
      constructor(entries) {
        this._entries = entries ? new Map(entries) : /* @__PURE__ */ new Map();
      }
      getEntry(key) {
        const entry = this._entries.get(key);
        if (!entry) {
          return void 0;
        }
        return Object.assign({}, entry);
      }
      getAllEntries() {
        return Array.from(this._entries.entries()).map(([k, v]) => [k, v]);
      }
      setEntry(key, entry) {
        const newBaggage = new BaggageImpl(this._entries);
        newBaggage._entries.set(key, entry);
        return newBaggage;
      }
      removeEntry(key) {
        const newBaggage = new BaggageImpl(this._entries);
        newBaggage._entries.delete(key);
        return newBaggage;
      }
      removeEntries(...keys) {
        const newBaggage = new BaggageImpl(this._entries);
        for (const key of keys) {
          newBaggage._entries.delete(key);
        }
        return newBaggage;
      }
      clear() {
        return new BaggageImpl();
      }
    };
    exports2.BaggageImpl = BaggageImpl;
  }
});

// node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js
var require_symbol = __commonJS({
  "node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageEntryMetadataSymbol = void 0;
    exports2.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
  }
});

// node_modules/@opentelemetry/api/build/src/baggage/utils.js
var require_utils = __commonJS({
  "node_modules/@opentelemetry/api/build/src/baggage/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageEntryMetadataFromString = exports2.createBaggage = void 0;
    var diag_1 = require_diag();
    var baggage_impl_1 = require_baggage_impl();
    var symbol_1 = require_symbol();
    var diag = diag_1.DiagAPI.instance();
    function createBaggage(entries = {}) {
      return new baggage_impl_1.BaggageImpl(new Map(Object.entries(entries)));
    }
    exports2.createBaggage = createBaggage;
    function baggageEntryMetadataFromString(str) {
      if (typeof str !== "string") {
        diag.error(`Cannot create baggage metadata from unknown type: ${typeof str}`);
        str = "";
      }
      return {
        __TYPE__: symbol_1.baggageEntryMetadataSymbol,
        toString() {
          return str;
        }
      };
    }
    exports2.baggageEntryMetadataFromString = baggageEntryMetadataFromString;
  }
});

// node_modules/@opentelemetry/api/build/src/context/context.js
var require_context = __commonJS({
  "node_modules/@opentelemetry/api/build/src/context/context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ROOT_CONTEXT = exports2.createContextKey = void 0;
    function createContextKey(description) {
      return Symbol.for(description);
    }
    exports2.createContextKey = createContextKey;
    var BaseContext = class {
      /**
       * Construct a new context which inherits values from an optional parent context.
       *
       * @param parentContext a context from which to inherit values
       */
      constructor(parentContext) {
        const self2 = this;
        self2._currentContext = parentContext ? new Map(parentContext) : /* @__PURE__ */ new Map();
        self2.getValue = (key) => self2._currentContext.get(key);
        self2.setValue = (key, value) => {
          const context2 = new BaseContext(self2._currentContext);
          context2._currentContext.set(key, value);
          return context2;
        };
        self2.deleteValue = (key) => {
          const context2 = new BaseContext(self2._currentContext);
          context2._currentContext.delete(key);
          return context2;
        };
      }
    };
    exports2.ROOT_CONTEXT = new BaseContext();
  }
});

// node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js
var require_consoleLogger = __commonJS({
  "node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagConsoleLogger = void 0;
    var consoleMap = [
      { n: "error", c: "error" },
      { n: "warn", c: "warn" },
      { n: "info", c: "info" },
      { n: "debug", c: "debug" },
      { n: "verbose", c: "trace" }
    ];
    var DiagConsoleLogger = class {
      constructor() {
        function _consoleFunc(funcName) {
          return function(...args) {
            if (console) {
              let theFunc = console[funcName];
              if (typeof theFunc !== "function") {
                theFunc = console.log;
              }
              if (typeof theFunc === "function") {
                return theFunc.apply(console, args);
              }
            }
          };
        }
        for (let i = 0; i < consoleMap.length; i++) {
          this[consoleMap[i].n] = _consoleFunc(consoleMap[i].c);
        }
      }
    };
    exports2.DiagConsoleLogger = DiagConsoleLogger;
  }
});

// node_modules/@opentelemetry/api/build/src/metrics/NoopMeter.js
var require_NoopMeter = __commonJS({
  "node_modules/@opentelemetry/api/build/src/metrics/NoopMeter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createNoopMeter = exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = exports2.NOOP_OBSERVABLE_GAUGE_METRIC = exports2.NOOP_OBSERVABLE_COUNTER_METRIC = exports2.NOOP_UP_DOWN_COUNTER_METRIC = exports2.NOOP_HISTOGRAM_METRIC = exports2.NOOP_COUNTER_METRIC = exports2.NOOP_METER = exports2.NoopObservableUpDownCounterMetric = exports2.NoopObservableGaugeMetric = exports2.NoopObservableCounterMetric = exports2.NoopObservableMetric = exports2.NoopHistogramMetric = exports2.NoopUpDownCounterMetric = exports2.NoopCounterMetric = exports2.NoopMetric = exports2.NoopMeter = void 0;
    var NoopMeter = class {
      constructor() {
      }
      /**
       * @see {@link Meter.createHistogram}
       */
      createHistogram(_name, _options) {
        return exports2.NOOP_HISTOGRAM_METRIC;
      }
      /**
       * @see {@link Meter.createCounter}
       */
      createCounter(_name, _options) {
        return exports2.NOOP_COUNTER_METRIC;
      }
      /**
       * @see {@link Meter.createUpDownCounter}
       */
      createUpDownCounter(_name, _options) {
        return exports2.NOOP_UP_DOWN_COUNTER_METRIC;
      }
      /**
       * @see {@link Meter.createObservableGauge}
       */
      createObservableGauge(_name, _options) {
        return exports2.NOOP_OBSERVABLE_GAUGE_METRIC;
      }
      /**
       * @see {@link Meter.createObservableCounter}
       */
      createObservableCounter(_name, _options) {
        return exports2.NOOP_OBSERVABLE_COUNTER_METRIC;
      }
      /**
       * @see {@link Meter.createObservableUpDownCounter}
       */
      createObservableUpDownCounter(_name, _options) {
        return exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
      }
      /**
       * @see {@link Meter.addBatchObservableCallback}
       */
      addBatchObservableCallback(_callback, _observables) {
      }
      /**
       * @see {@link Meter.removeBatchObservableCallback}
       */
      removeBatchObservableCallback(_callback) {
      }
    };
    exports2.NoopMeter = NoopMeter;
    var NoopMetric = class {
    };
    exports2.NoopMetric = NoopMetric;
    var NoopCounterMetric = class extends NoopMetric {
      add(_value, _attributes) {
      }
    };
    exports2.NoopCounterMetric = NoopCounterMetric;
    var NoopUpDownCounterMetric = class extends NoopMetric {
      add(_value, _attributes) {
      }
    };
    exports2.NoopUpDownCounterMetric = NoopUpDownCounterMetric;
    var NoopHistogramMetric = class extends NoopMetric {
      record(_value, _attributes) {
      }
    };
    exports2.NoopHistogramMetric = NoopHistogramMetric;
    var NoopObservableMetric = class {
      addCallback(_callback) {
      }
      removeCallback(_callback) {
      }
    };
    exports2.NoopObservableMetric = NoopObservableMetric;
    var NoopObservableCounterMetric = class extends NoopObservableMetric {
    };
    exports2.NoopObservableCounterMetric = NoopObservableCounterMetric;
    var NoopObservableGaugeMetric = class extends NoopObservableMetric {
    };
    exports2.NoopObservableGaugeMetric = NoopObservableGaugeMetric;
    var NoopObservableUpDownCounterMetric = class extends NoopObservableMetric {
    };
    exports2.NoopObservableUpDownCounterMetric = NoopObservableUpDownCounterMetric;
    exports2.NOOP_METER = new NoopMeter();
    exports2.NOOP_COUNTER_METRIC = new NoopCounterMetric();
    exports2.NOOP_HISTOGRAM_METRIC = new NoopHistogramMetric();
    exports2.NOOP_UP_DOWN_COUNTER_METRIC = new NoopUpDownCounterMetric();
    exports2.NOOP_OBSERVABLE_COUNTER_METRIC = new NoopObservableCounterMetric();
    exports2.NOOP_OBSERVABLE_GAUGE_METRIC = new NoopObservableGaugeMetric();
    exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new NoopObservableUpDownCounterMetric();
    function createNoopMeter() {
      return exports2.NOOP_METER;
    }
    exports2.createNoopMeter = createNoopMeter;
  }
});

// node_modules/@opentelemetry/api/build/src/metrics/Metric.js
var require_Metric = __commonJS({
  "node_modules/@opentelemetry/api/build/src/metrics/Metric.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ValueType = void 0;
    var ValueType;
    (function(ValueType2) {
      ValueType2[ValueType2["INT"] = 0] = "INT";
      ValueType2[ValueType2["DOUBLE"] = 1] = "DOUBLE";
    })(ValueType = exports2.ValueType || (exports2.ValueType = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js
var require_TextMapPropagator = __commonJS({
  "node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultTextMapSetter = exports2.defaultTextMapGetter = void 0;
    exports2.defaultTextMapGetter = {
      get(carrier, key) {
        if (carrier == null) {
          return void 0;
        }
        return carrier[key];
      },
      keys(carrier) {
        if (carrier == null) {
          return [];
        }
        return Object.keys(carrier);
      }
    };
    exports2.defaultTextMapSetter = {
      set(carrier, key, value) {
        if (carrier == null) {
          return;
        }
        carrier[key] = value;
      }
    };
  }
});

// node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js
var require_NoopContextManager = __commonJS({
  "node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopContextManager = void 0;
    var context_1 = require_context();
    var NoopContextManager = class {
      active() {
        return context_1.ROOT_CONTEXT;
      }
      with(_context, fn, thisArg, ...args) {
        return fn.call(thisArg, ...args);
      }
      bind(_context, target) {
        return target;
      }
      enable() {
        return this;
      }
      disable() {
        return this;
      }
    };
    exports2.NoopContextManager = NoopContextManager;
  }
});

// node_modules/@opentelemetry/api/build/src/api/context.js
var require_context2 = __commonJS({
  "node_modules/@opentelemetry/api/build/src/api/context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ContextAPI = void 0;
    var NoopContextManager_1 = require_NoopContextManager();
    var global_utils_1 = require_global_utils();
    var diag_1 = require_diag();
    var API_NAME = "context";
    var NOOP_CONTEXT_MANAGER = new NoopContextManager_1.NoopContextManager();
    var ContextAPI = class {
      /** Empty private constructor prevents end users from constructing a new instance of the API */
      constructor() {
      }
      /** Get the singleton instance of the Context API */
      static getInstance() {
        if (!this._instance) {
          this._instance = new ContextAPI();
        }
        return this._instance;
      }
      /**
       * Set the current context manager.
       *
       * @returns true if the context manager was successfully registered, else false
       */
      setGlobalContextManager(contextManager) {
        return (0, global_utils_1.registerGlobal)(API_NAME, contextManager, diag_1.DiagAPI.instance());
      }
      /**
       * Get the currently active context
       */
      active() {
        return this._getContextManager().active();
      }
      /**
       * Execute a function with an active context
       *
       * @param context context to be active during function execution
       * @param fn function to execute in a context
       * @param thisArg optional receiver to be used for calling fn
       * @param args optional arguments forwarded to fn
       */
      with(context2, fn, thisArg, ...args) {
        return this._getContextManager().with(context2, fn, thisArg, ...args);
      }
      /**
       * Bind a context to a target function or event emitter
       *
       * @param context context to bind to the event emitter or function. Defaults to the currently active context
       * @param target function or event emitter to bind
       */
      bind(context2, target) {
        return this._getContextManager().bind(context2, target);
      }
      _getContextManager() {
        return (0, global_utils_1.getGlobal)(API_NAME) || NOOP_CONTEXT_MANAGER;
      }
      /** Disable and remove the global context manager */
      disable() {
        this._getContextManager().disable();
        (0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
      }
    };
    exports2.ContextAPI = ContextAPI;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/trace_flags.js
var require_trace_flags = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/trace_flags.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceFlags = void 0;
    var TraceFlags;
    (function(TraceFlags2) {
      TraceFlags2[TraceFlags2["NONE"] = 0] = "NONE";
      TraceFlags2[TraceFlags2["SAMPLED"] = 1] = "SAMPLED";
    })(TraceFlags = exports2.TraceFlags || (exports2.TraceFlags = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/trace/invalid-span-constants.js
var require_invalid_span_constants = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/invalid-span-constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = void 0;
    var trace_flags_1 = require_trace_flags();
    exports2.INVALID_SPANID = "0000000000000000";
    exports2.INVALID_TRACEID = "00000000000000000000000000000000";
    exports2.INVALID_SPAN_CONTEXT = {
      traceId: exports2.INVALID_TRACEID,
      spanId: exports2.INVALID_SPANID,
      traceFlags: trace_flags_1.TraceFlags.NONE
    };
  }
});

// node_modules/@opentelemetry/api/build/src/trace/NonRecordingSpan.js
var require_NonRecordingSpan = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/NonRecordingSpan.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NonRecordingSpan = void 0;
    var invalid_span_constants_1 = require_invalid_span_constants();
    var NonRecordingSpan = class {
      constructor(_spanContext = invalid_span_constants_1.INVALID_SPAN_CONTEXT) {
        this._spanContext = _spanContext;
      }
      // Returns a SpanContext.
      spanContext() {
        return this._spanContext;
      }
      // By default does nothing
      setAttribute(_key, _value) {
        return this;
      }
      // By default does nothing
      setAttributes(_attributes) {
        return this;
      }
      // By default does nothing
      addEvent(_name, _attributes) {
        return this;
      }
      // By default does nothing
      setStatus(_status) {
        return this;
      }
      // By default does nothing
      updateName(_name) {
        return this;
      }
      // By default does nothing
      end(_endTime) {
      }
      // isRecording always returns false for NonRecordingSpan.
      isRecording() {
        return false;
      }
      // By default does nothing
      recordException(_exception, _time) {
      }
    };
    exports2.NonRecordingSpan = NonRecordingSpan;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/context-utils.js
var require_context_utils = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/context-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getSpanContext = exports2.setSpanContext = exports2.deleteSpan = exports2.setSpan = exports2.getActiveSpan = exports2.getSpan = void 0;
    var context_1 = require_context();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var context_2 = require_context2();
    var SPAN_KEY = (0, context_1.createContextKey)("OpenTelemetry Context Key SPAN");
    function getSpan(context2) {
      return context2.getValue(SPAN_KEY) || void 0;
    }
    exports2.getSpan = getSpan;
    function getActiveSpan() {
      return getSpan(context_2.ContextAPI.getInstance().active());
    }
    exports2.getActiveSpan = getActiveSpan;
    function setSpan(context2, span) {
      return context2.setValue(SPAN_KEY, span);
    }
    exports2.setSpan = setSpan;
    function deleteSpan(context2) {
      return context2.deleteValue(SPAN_KEY);
    }
    exports2.deleteSpan = deleteSpan;
    function setSpanContext(context2, spanContext) {
      return setSpan(context2, new NonRecordingSpan_1.NonRecordingSpan(spanContext));
    }
    exports2.setSpanContext = setSpanContext;
    function getSpanContext(context2) {
      var _a;
      return (_a = getSpan(context2)) === null || _a === void 0 ? void 0 : _a.spanContext();
    }
    exports2.getSpanContext = getSpanContext;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js
var require_spancontext_utils = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.wrapSpanContext = exports2.isSpanContextValid = exports2.isValidSpanId = exports2.isValidTraceId = void 0;
    var invalid_span_constants_1 = require_invalid_span_constants();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var VALID_TRACEID_REGEX = /^([0-9a-f]{32})$/i;
    var VALID_SPANID_REGEX = /^[0-9a-f]{16}$/i;
    function isValidTraceId(traceId) {
      return VALID_TRACEID_REGEX.test(traceId) && traceId !== invalid_span_constants_1.INVALID_TRACEID;
    }
    exports2.isValidTraceId = isValidTraceId;
    function isValidSpanId(spanId) {
      return VALID_SPANID_REGEX.test(spanId) && spanId !== invalid_span_constants_1.INVALID_SPANID;
    }
    exports2.isValidSpanId = isValidSpanId;
    function isSpanContextValid(spanContext) {
      return isValidTraceId(spanContext.traceId) && isValidSpanId(spanContext.spanId);
    }
    exports2.isSpanContextValid = isSpanContextValid;
    function wrapSpanContext(spanContext) {
      return new NonRecordingSpan_1.NonRecordingSpan(spanContext);
    }
    exports2.wrapSpanContext = wrapSpanContext;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js
var require_NoopTracer = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTracer = void 0;
    var context_1 = require_context2();
    var context_utils_1 = require_context_utils();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var spancontext_utils_1 = require_spancontext_utils();
    var contextApi = context_1.ContextAPI.getInstance();
    var NoopTracer = class {
      // startSpan starts a noop span.
      startSpan(name, options, context2) {
        const root = Boolean(options === null || options === void 0 ? void 0 : options.root);
        if (root) {
          return new NonRecordingSpan_1.NonRecordingSpan();
        }
        const parentFromContext = context2 && (0, context_utils_1.getSpanContext)(context2);
        if (isSpanContext(parentFromContext) && (0, spancontext_utils_1.isSpanContextValid)(parentFromContext)) {
          return new NonRecordingSpan_1.NonRecordingSpan(parentFromContext);
        } else {
          return new NonRecordingSpan_1.NonRecordingSpan();
        }
      }
      startActiveSpan(name, arg2, arg3, arg4) {
        let opts;
        let ctx;
        let fn;
        if (arguments.length < 2) {
          return;
        } else if (arguments.length === 2) {
          fn = arg2;
        } else if (arguments.length === 3) {
          opts = arg2;
          fn = arg3;
        } else {
          opts = arg2;
          ctx = arg3;
          fn = arg4;
        }
        const parentContext = ctx !== null && ctx !== void 0 ? ctx : contextApi.active();
        const span = this.startSpan(name, opts, parentContext);
        const contextWithSpanSet = (0, context_utils_1.setSpan)(parentContext, span);
        return contextApi.with(contextWithSpanSet, fn, void 0, span);
      }
    };
    exports2.NoopTracer = NoopTracer;
    function isSpanContext(spanContext) {
      return typeof spanContext === "object" && typeof spanContext["spanId"] === "string" && typeof spanContext["traceId"] === "string" && typeof spanContext["traceFlags"] === "number";
    }
  }
});

// node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js
var require_ProxyTracer = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ProxyTracer = void 0;
    var NoopTracer_1 = require_NoopTracer();
    var NOOP_TRACER = new NoopTracer_1.NoopTracer();
    var ProxyTracer = class {
      constructor(_provider, name, version, options) {
        this._provider = _provider;
        this.name = name;
        this.version = version;
        this.options = options;
      }
      startSpan(name, options, context2) {
        return this._getTracer().startSpan(name, options, context2);
      }
      startActiveSpan(_name, _options, _context, _fn) {
        const tracer = this._getTracer();
        return Reflect.apply(tracer.startActiveSpan, tracer, arguments);
      }
      /**
       * Try to get a tracer from the proxy tracer provider.
       * If the proxy tracer provider has no delegate, return a noop tracer.
       */
      _getTracer() {
        if (this._delegate) {
          return this._delegate;
        }
        const tracer = this._provider.getDelegateTracer(this.name, this.version, this.options);
        if (!tracer) {
          return NOOP_TRACER;
        }
        this._delegate = tracer;
        return this._delegate;
      }
    };
    exports2.ProxyTracer = ProxyTracer;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js
var require_NoopTracerProvider = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTracerProvider = void 0;
    var NoopTracer_1 = require_NoopTracer();
    var NoopTracerProvider = class {
      getTracer(_name, _version, _options) {
        return new NoopTracer_1.NoopTracer();
      }
    };
    exports2.NoopTracerProvider = NoopTracerProvider;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js
var require_ProxyTracerProvider = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ProxyTracerProvider = void 0;
    var ProxyTracer_1 = require_ProxyTracer();
    var NoopTracerProvider_1 = require_NoopTracerProvider();
    var NOOP_TRACER_PROVIDER = new NoopTracerProvider_1.NoopTracerProvider();
    var ProxyTracerProvider = class {
      /**
       * Get a {@link ProxyTracer}
       */
      getTracer(name, version, options) {
        var _a;
        return (_a = this.getDelegateTracer(name, version, options)) !== null && _a !== void 0 ? _a : new ProxyTracer_1.ProxyTracer(this, name, version, options);
      }
      getDelegate() {
        var _a;
        return (_a = this._delegate) !== null && _a !== void 0 ? _a : NOOP_TRACER_PROVIDER;
      }
      /**
       * Set the delegate tracer provider
       */
      setDelegate(delegate) {
        this._delegate = delegate;
      }
      getDelegateTracer(name, version, options) {
        var _a;
        return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version, options);
      }
    };
    exports2.ProxyTracerProvider = ProxyTracerProvider;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js
var require_SamplingResult = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SamplingDecision = void 0;
    var SamplingDecision;
    (function(SamplingDecision2) {
      SamplingDecision2[SamplingDecision2["NOT_RECORD"] = 0] = "NOT_RECORD";
      SamplingDecision2[SamplingDecision2["RECORD"] = 1] = "RECORD";
      SamplingDecision2[SamplingDecision2["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
    })(SamplingDecision = exports2.SamplingDecision || (exports2.SamplingDecision = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/trace/span_kind.js
var require_span_kind = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/span_kind.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SpanKind = void 0;
    var SpanKind;
    (function(SpanKind2) {
      SpanKind2[SpanKind2["INTERNAL"] = 0] = "INTERNAL";
      SpanKind2[SpanKind2["SERVER"] = 1] = "SERVER";
      SpanKind2[SpanKind2["CLIENT"] = 2] = "CLIENT";
      SpanKind2[SpanKind2["PRODUCER"] = 3] = "PRODUCER";
      SpanKind2[SpanKind2["CONSUMER"] = 4] = "CONSUMER";
    })(SpanKind = exports2.SpanKind || (exports2.SpanKind = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/trace/status.js
var require_status = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/status.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SpanStatusCode = void 0;
    var SpanStatusCode;
    (function(SpanStatusCode2) {
      SpanStatusCode2[SpanStatusCode2["UNSET"] = 0] = "UNSET";
      SpanStatusCode2[SpanStatusCode2["OK"] = 1] = "OK";
      SpanStatusCode2[SpanStatusCode2["ERROR"] = 2] = "ERROR";
    })(SpanStatusCode = exports2.SpanStatusCode || (exports2.SpanStatusCode = {}));
  }
});

// node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-validators.js
var require_tracestate_validators = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-validators.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.validateValue = exports2.validateKey = void 0;
    var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
    var VALID_KEY = `[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`;
    var VALID_VENDOR_KEY = `[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`;
    var VALID_KEY_REGEX = new RegExp(`^(?:${VALID_KEY}|${VALID_VENDOR_KEY})$`);
    var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
    var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
    function validateKey(key) {
      return VALID_KEY_REGEX.test(key);
    }
    exports2.validateKey = validateKey;
    function validateValue(value) {
      return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
    }
    exports2.validateValue = validateValue;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-impl.js
var require_tracestate_impl = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-impl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceStateImpl = void 0;
    var tracestate_validators_1 = require_tracestate_validators();
    var MAX_TRACE_STATE_ITEMS = 32;
    var MAX_TRACE_STATE_LEN = 512;
    var LIST_MEMBERS_SEPARATOR = ",";
    var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
    var TraceStateImpl = class {
      constructor(rawTraceState) {
        this._internalState = /* @__PURE__ */ new Map();
        if (rawTraceState)
          this._parse(rawTraceState);
      }
      set(key, value) {
        const traceState = this._clone();
        if (traceState._internalState.has(key)) {
          traceState._internalState.delete(key);
        }
        traceState._internalState.set(key, value);
        return traceState;
      }
      unset(key) {
        const traceState = this._clone();
        traceState._internalState.delete(key);
        return traceState;
      }
      get(key) {
        return this._internalState.get(key);
      }
      serialize() {
        return this._keys().reduce((agg, key) => {
          agg.push(key + LIST_MEMBER_KEY_VALUE_SPLITTER + this.get(key));
          return agg;
        }, []).join(LIST_MEMBERS_SEPARATOR);
      }
      _parse(rawTraceState) {
        if (rawTraceState.length > MAX_TRACE_STATE_LEN)
          return;
        this._internalState = rawTraceState.split(LIST_MEMBERS_SEPARATOR).reverse().reduce((agg, part) => {
          const listMember = part.trim();
          const i = listMember.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
          if (i !== -1) {
            const key = listMember.slice(0, i);
            const value = listMember.slice(i + 1, part.length);
            if ((0, tracestate_validators_1.validateKey)(key) && (0, tracestate_validators_1.validateValue)(value)) {
              agg.set(key, value);
            } else {
            }
          }
          return agg;
        }, /* @__PURE__ */ new Map());
        if (this._internalState.size > MAX_TRACE_STATE_ITEMS) {
          this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, MAX_TRACE_STATE_ITEMS));
        }
      }
      _keys() {
        return Array.from(this._internalState.keys()).reverse();
      }
      _clone() {
        const traceState = new TraceStateImpl();
        traceState._internalState = new Map(this._internalState);
        return traceState;
      }
    };
    exports2.TraceStateImpl = TraceStateImpl;
  }
});

// node_modules/@opentelemetry/api/build/src/trace/internal/utils.js
var require_utils2 = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace/internal/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createTraceState = void 0;
    var tracestate_impl_1 = require_tracestate_impl();
    function createTraceState(rawTraceState) {
      return new tracestate_impl_1.TraceStateImpl(rawTraceState);
    }
    exports2.createTraceState = createTraceState;
  }
});

// node_modules/@opentelemetry/api/build/src/context-api.js
var require_context_api = __commonJS({
  "node_modules/@opentelemetry/api/build/src/context-api.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.context = void 0;
    var context_1 = require_context2();
    exports2.context = context_1.ContextAPI.getInstance();
  }
});

// node_modules/@opentelemetry/api/build/src/diag-api.js
var require_diag_api = __commonJS({
  "node_modules/@opentelemetry/api/build/src/diag-api.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.diag = void 0;
    var diag_1 = require_diag();
    exports2.diag = diag_1.DiagAPI.instance();
  }
});

// node_modules/@opentelemetry/api/build/src/metrics/NoopMeterProvider.js
var require_NoopMeterProvider = __commonJS({
  "node_modules/@opentelemetry/api/build/src/metrics/NoopMeterProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NOOP_METER_PROVIDER = exports2.NoopMeterProvider = void 0;
    var NoopMeter_1 = require_NoopMeter();
    var NoopMeterProvider = class {
      getMeter(_name, _version, _options) {
        return NoopMeter_1.NOOP_METER;
      }
    };
    exports2.NoopMeterProvider = NoopMeterProvider;
    exports2.NOOP_METER_PROVIDER = new NoopMeterProvider();
  }
});

// node_modules/@opentelemetry/api/build/src/api/metrics.js
var require_metrics = __commonJS({
  "node_modules/@opentelemetry/api/build/src/api/metrics.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MetricsAPI = void 0;
    var NoopMeterProvider_1 = require_NoopMeterProvider();
    var global_utils_1 = require_global_utils();
    var diag_1 = require_diag();
    var API_NAME = "metrics";
    var MetricsAPI = class {
      /** Empty private constructor prevents end users from constructing a new instance of the API */
      constructor() {
      }
      /** Get the singleton instance of the Metrics API */
      static getInstance() {
        if (!this._instance) {
          this._instance = new MetricsAPI();
        }
        return this._instance;
      }
      /**
       * Set the current global meter provider.
       * Returns true if the meter provider was successfully registered, else false.
       */
      setGlobalMeterProvider(provider) {
        return (0, global_utils_1.registerGlobal)(API_NAME, provider, diag_1.DiagAPI.instance());
      }
      /**
       * Returns the global meter provider.
       */
      getMeterProvider() {
        return (0, global_utils_1.getGlobal)(API_NAME) || NoopMeterProvider_1.NOOP_METER_PROVIDER;
      }
      /**
       * Returns a meter from the global meter provider.
       */
      getMeter(name, version, options) {
        return this.getMeterProvider().getMeter(name, version, options);
      }
      /** Remove the global meter provider */
      disable() {
        (0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
      }
    };
    exports2.MetricsAPI = MetricsAPI;
  }
});

// node_modules/@opentelemetry/api/build/src/metrics-api.js
var require_metrics_api = __commonJS({
  "node_modules/@opentelemetry/api/build/src/metrics-api.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.metrics = void 0;
    var metrics_1 = require_metrics();
    exports2.metrics = metrics_1.MetricsAPI.getInstance();
  }
});

// node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js
var require_NoopTextMapPropagator = __commonJS({
  "node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTextMapPropagator = void 0;
    var NoopTextMapPropagator = class {
      /** Noop inject function does nothing */
      inject(_context, _carrier) {
      }
      /** Noop extract function does nothing and returns the input context */
      extract(context2, _carrier) {
        return context2;
      }
      fields() {
        return [];
      }
    };
    exports2.NoopTextMapPropagator = NoopTextMapPropagator;
  }
});

// node_modules/@opentelemetry/api/build/src/baggage/context-helpers.js
var require_context_helpers = __commonJS({
  "node_modules/@opentelemetry/api/build/src/baggage/context-helpers.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.deleteBaggage = exports2.setBaggage = exports2.getBaggage = void 0;
    var context_1 = require_context();
    var BAGGAGE_KEY = (0, context_1.createContextKey)("OpenTelemetry Baggage Key");
    function getBaggage(context2) {
      return context2.getValue(BAGGAGE_KEY) || void 0;
    }
    exports2.getBaggage = getBaggage;
    function setBaggage(context2, baggage) {
      return context2.setValue(BAGGAGE_KEY, baggage);
    }
    exports2.setBaggage = setBaggage;
    function deleteBaggage(context2) {
      return context2.deleteValue(BAGGAGE_KEY);
    }
    exports2.deleteBaggage = deleteBaggage;
  }
});

// node_modules/@opentelemetry/api/build/src/api/propagation.js
var require_propagation = __commonJS({
  "node_modules/@opentelemetry/api/build/src/api/propagation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.PropagationAPI = void 0;
    var global_utils_1 = require_global_utils();
    var NoopTextMapPropagator_1 = require_NoopTextMapPropagator();
    var TextMapPropagator_1 = require_TextMapPropagator();
    var context_helpers_1 = require_context_helpers();
    var utils_1 = require_utils();
    var diag_1 = require_diag();
    var API_NAME = "propagation";
    var NOOP_TEXT_MAP_PROPAGATOR = new NoopTextMapPropagator_1.NoopTextMapPropagator();
    var PropagationAPI = class {
      /** Empty private constructor prevents end users from constructing a new instance of the API */
      constructor() {
        this.createBaggage = utils_1.createBaggage;
        this.getBaggage = context_helpers_1.getBaggage;
        this.setBaggage = context_helpers_1.setBaggage;
        this.deleteBaggage = context_helpers_1.deleteBaggage;
      }
      /** Get the singleton instance of the Propagator API */
      static getInstance() {
        if (!this._instance) {
          this._instance = new PropagationAPI();
        }
        return this._instance;
      }
      /**
       * Set the current propagator.
       *
       * @returns true if the propagator was successfully registered, else false
       */
      setGlobalPropagator(propagator) {
        return (0, global_utils_1.registerGlobal)(API_NAME, propagator, diag_1.DiagAPI.instance());
      }
      /**
       * Inject context into a carrier to be propagated inter-process
       *
       * @param context Context carrying tracing data to inject
       * @param carrier carrier to inject context into
       * @param setter Function used to set values on the carrier
       */
      inject(context2, carrier, setter = TextMapPropagator_1.defaultTextMapSetter) {
        return this._getGlobalPropagator().inject(context2, carrier, setter);
      }
      /**
       * Extract context from a carrier
       *
       * @param context Context which the newly created context will inherit from
       * @param carrier Carrier to extract context from
       * @param getter Function used to extract keys from a carrier
       */
      extract(context2, carrier, getter = TextMapPropagator_1.defaultTextMapGetter) {
        return this._getGlobalPropagator().extract(context2, carrier, getter);
      }
      /**
       * Return a list of all fields which may be used by the propagator.
       */
      fields() {
        return this._getGlobalPropagator().fields();
      }
      /** Remove the global propagator */
      disable() {
        (0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
      }
      _getGlobalPropagator() {
        return (0, global_utils_1.getGlobal)(API_NAME) || NOOP_TEXT_MAP_PROPAGATOR;
      }
    };
    exports2.PropagationAPI = PropagationAPI;
  }
});

// node_modules/@opentelemetry/api/build/src/propagation-api.js
var require_propagation_api = __commonJS({
  "node_modules/@opentelemetry/api/build/src/propagation-api.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.propagation = void 0;
    var propagation_1 = require_propagation();
    exports2.propagation = propagation_1.PropagationAPI.getInstance();
  }
});

// node_modules/@opentelemetry/api/build/src/api/trace.js
var require_trace = __commonJS({
  "node_modules/@opentelemetry/api/build/src/api/trace.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceAPI = void 0;
    var global_utils_1 = require_global_utils();
    var ProxyTracerProvider_1 = require_ProxyTracerProvider();
    var spancontext_utils_1 = require_spancontext_utils();
    var context_utils_1 = require_context_utils();
    var diag_1 = require_diag();
    var API_NAME = "trace";
    var TraceAPI = class {
      /** Empty private constructor prevents end users from constructing a new instance of the API */
      constructor() {
        this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
        this.wrapSpanContext = spancontext_utils_1.wrapSpanContext;
        this.isSpanContextValid = spancontext_utils_1.isSpanContextValid;
        this.deleteSpan = context_utils_1.deleteSpan;
        this.getSpan = context_utils_1.getSpan;
        this.getActiveSpan = context_utils_1.getActiveSpan;
        this.getSpanContext = context_utils_1.getSpanContext;
        this.setSpan = context_utils_1.setSpan;
        this.setSpanContext = context_utils_1.setSpanContext;
      }
      /** Get the singleton instance of the Trace API */
      static getInstance() {
        if (!this._instance) {
          this._instance = new TraceAPI();
        }
        return this._instance;
      }
      /**
       * Set the current global tracer.
       *
       * @returns true if the tracer provider was successfully registered, else false
       */
      setGlobalTracerProvider(provider) {
        const success = (0, global_utils_1.registerGlobal)(API_NAME, this._proxyTracerProvider, diag_1.DiagAPI.instance());
        if (success) {
          this._proxyTracerProvider.setDelegate(provider);
        }
        return success;
      }
      /**
       * Returns the global tracer provider.
       */
      getTracerProvider() {
        return (0, global_utils_1.getGlobal)(API_NAME) || this._proxyTracerProvider;
      }
      /**
       * Returns a tracer from the global tracer provider.
       */
      getTracer(name, version) {
        return this.getTracerProvider().getTracer(name, version);
      }
      /** Remove the global tracer provider */
      disable() {
        (0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
        this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
      }
    };
    exports2.TraceAPI = TraceAPI;
  }
});

// node_modules/@opentelemetry/api/build/src/trace-api.js
var require_trace_api = __commonJS({
  "node_modules/@opentelemetry/api/build/src/trace-api.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.trace = void 0;
    var trace_1 = require_trace();
    exports2.trace = trace_1.TraceAPI.getInstance();
  }
});

// node_modules/@opentelemetry/api/build/src/index.js
var require_src = __commonJS({
  "node_modules/@opentelemetry/api/build/src/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.trace = exports2.propagation = exports2.metrics = exports2.diag = exports2.context = exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = exports2.isValidSpanId = exports2.isValidTraceId = exports2.isSpanContextValid = exports2.createTraceState = exports2.TraceFlags = exports2.SpanStatusCode = exports2.SpanKind = exports2.SamplingDecision = exports2.ProxyTracerProvider = exports2.ProxyTracer = exports2.defaultTextMapSetter = exports2.defaultTextMapGetter = exports2.ValueType = exports2.createNoopMeter = exports2.DiagLogLevel = exports2.DiagConsoleLogger = exports2.ROOT_CONTEXT = exports2.createContextKey = exports2.baggageEntryMetadataFromString = void 0;
    var utils_1 = require_utils();
    Object.defineProperty(exports2, "baggageEntryMetadataFromString", { enumerable: true, get: function() {
      return utils_1.baggageEntryMetadataFromString;
    } });
    var context_1 = require_context();
    Object.defineProperty(exports2, "createContextKey", { enumerable: true, get: function() {
      return context_1.createContextKey;
    } });
    Object.defineProperty(exports2, "ROOT_CONTEXT", { enumerable: true, get: function() {
      return context_1.ROOT_CONTEXT;
    } });
    var consoleLogger_1 = require_consoleLogger();
    Object.defineProperty(exports2, "DiagConsoleLogger", { enumerable: true, get: function() {
      return consoleLogger_1.DiagConsoleLogger;
    } });
    var types_1 = require_types();
    Object.defineProperty(exports2, "DiagLogLevel", { enumerable: true, get: function() {
      return types_1.DiagLogLevel;
    } });
    var NoopMeter_1 = require_NoopMeter();
    Object.defineProperty(exports2, "createNoopMeter", { enumerable: true, get: function() {
      return NoopMeter_1.createNoopMeter;
    } });
    var Metric_1 = require_Metric();
    Object.defineProperty(exports2, "ValueType", { enumerable: true, get: function() {
      return Metric_1.ValueType;
    } });
    var TextMapPropagator_1 = require_TextMapPropagator();
    Object.defineProperty(exports2, "defaultTextMapGetter", { enumerable: true, get: function() {
      return TextMapPropagator_1.defaultTextMapGetter;
    } });
    Object.defineProperty(exports2, "defaultTextMapSetter", { enumerable: true, get: function() {
      return TextMapPropagator_1.defaultTextMapSetter;
    } });
    var ProxyTracer_1 = require_ProxyTracer();
    Object.defineProperty(exports2, "ProxyTracer", { enumerable: true, get: function() {
      return ProxyTracer_1.ProxyTracer;
    } });
    var ProxyTracerProvider_1 = require_ProxyTracerProvider();
    Object.defineProperty(exports2, "ProxyTracerProvider", { enumerable: true, get: function() {
      return ProxyTracerProvider_1.ProxyTracerProvider;
    } });
    var SamplingResult_1 = require_SamplingResult();
    Object.defineProperty(exports2, "SamplingDecision", { enumerable: true, get: function() {
      return SamplingResult_1.SamplingDecision;
    } });
    var span_kind_1 = require_span_kind();
    Object.defineProperty(exports2, "SpanKind", { enumerable: true, get: function() {
      return span_kind_1.SpanKind;
    } });
    var status_1 = require_status();
    Object.defineProperty(exports2, "SpanStatusCode", { enumerable: true, get: function() {
      return status_1.SpanStatusCode;
    } });
    var trace_flags_1 = require_trace_flags();
    Object.defineProperty(exports2, "TraceFlags", { enumerable: true, get: function() {
      return trace_flags_1.TraceFlags;
    } });
    var utils_2 = require_utils2();
    Object.defineProperty(exports2, "createTraceState", { enumerable: true, get: function() {
      return utils_2.createTraceState;
    } });
    var spancontext_utils_1 = require_spancontext_utils();
    Object.defineProperty(exports2, "isSpanContextValid", { enumerable: true, get: function() {
      return spancontext_utils_1.isSpanContextValid;
    } });
    Object.defineProperty(exports2, "isValidTraceId", { enumerable: true, get: function() {
      return spancontext_utils_1.isValidTraceId;
    } });
    Object.defineProperty(exports2, "isValidSpanId", { enumerable: true, get: function() {
      return spancontext_utils_1.isValidSpanId;
    } });
    var invalid_span_constants_1 = require_invalid_span_constants();
    Object.defineProperty(exports2, "INVALID_SPANID", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_SPANID;
    } });
    Object.defineProperty(exports2, "INVALID_TRACEID", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_TRACEID;
    } });
    Object.defineProperty(exports2, "INVALID_SPAN_CONTEXT", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_SPAN_CONTEXT;
    } });
    var context_api_1 = require_context_api();
    Object.defineProperty(exports2, "context", { enumerable: true, get: function() {
      return context_api_1.context;
    } });
    var diag_api_1 = require_diag_api();
    Object.defineProperty(exports2, "diag", { enumerable: true, get: function() {
      return diag_api_1.diag;
    } });
    var metrics_api_1 = require_metrics_api();
    Object.defineProperty(exports2, "metrics", { enumerable: true, get: function() {
      return metrics_api_1.metrics;
    } });
    var propagation_api_1 = require_propagation_api();
    Object.defineProperty(exports2, "propagation", { enumerable: true, get: function() {
      return propagation_api_1.propagation;
    } });
    var trace_api_1 = require_trace_api();
    Object.defineProperty(exports2, "trace", { enumerable: true, get: function() {
      return trace_api_1.trace;
    } });
    exports2.default = {
      context: context_api_1.context,
      diag: diag_api_1.diag,
      metrics: metrics_api_1.metrics,
      propagation: propagation_api_1.propagation,
      trace: trace_api_1.trace
    };
  }
});

// node_modules/@baselime/lambda-node-opentelemetry/index.js
var require_lambda_node_opentelemetry = __commonJS({
  "node_modules/@baselime/lambda-node-opentelemetry/index.js"(exports2, module2) {
    "use strict";
    var Ir = Object.create;
    var re = Object.defineProperty;
    var mr = Object.getOwnPropertyDescriptor;
    var hr = Object.getOwnPropertyNames;
    var xr = Object.getPrototypeOf;
    var Dr = Object.prototype.hasOwnProperty;
    var i = (t, e) => () => (e || t((e = { exports: {} }).exports, e), e.exports);
    var jr = (t, e) => {
      for (var r in e)
        re(t, r, { get: e[r], enumerable: true });
    };
    var St = (t, e, r, n) => {
      if (e && typeof e == "object" || typeof e == "function")
        for (let a of hr(e))
          !Dr.call(t, a) && a !== r && re(t, a, { get: () => e[a], enumerable: !(n = mr(e, a)) || n.enumerable });
      return t;
    };
    var Lr = (t, e, r) => (r = t != null ? Ir(xr(t)) : {}, St(e || !t || !t.__esModule ? re(r, "default", { value: t, enumerable: true }) : r, t));
    var Vr = (t) => St(re({}, "__esModule", { value: true }), t);
    var Mt = i((ne) => {
      "use strict";
      Object.defineProperty(ne, "__esModule", { value: true });
      ne._globalThis = void 0;
      ne._globalThis = typeof globalThis == "object" ? globalThis : global;
    });
    var Rt = i((N) => {
      "use strict";
      var wr = N && N.__createBinding || (Object.create ? function(t, e, r, n) {
        n === void 0 && (n = r), Object.defineProperty(t, n, { enumerable: true, get: function() {
          return e[r];
        } });
      } : function(t, e, r, n) {
        n === void 0 && (n = r), t[n] = e[r];
      }), qr = N && N.__exportStar || function(t, e) {
        for (var r in t)
          r !== "default" && !Object.prototype.hasOwnProperty.call(e, r) && wr(e, t, r);
      };
      Object.defineProperty(N, "__esModule", { value: true });
      qr(Mt(), N);
    });
    var Ct = i((y) => {
      "use strict";
      var Gr = y && y.__createBinding || (Object.create ? function(t, e, r, n) {
        n === void 0 && (n = r), Object.defineProperty(t, n, { enumerable: true, get: function() {
          return e[r];
        } });
      } : function(t, e, r, n) {
        n === void 0 && (n = r), t[n] = e[r];
      }), Br = y && y.__exportStar || function(t, e) {
        for (var r in t)
          r !== "default" && !Object.prototype.hasOwnProperty.call(e, r) && Gr(e, t, r);
      };
      Object.defineProperty(y, "__esModule", { value: true });
      Br(Rt(), y);
    });
    var ke = i((ae) => {
      "use strict";
      Object.defineProperty(ae, "__esModule", { value: true });
      ae.VERSION = void 0;
      ae.VERSION = "1.4.1";
    });
    var mt = i((R) => {
      "use strict";
      Object.defineProperty(R, "__esModule", { value: true });
      R.isCompatible = R._makeCompatibilityCheck = void 0;
      var Ur = ke(), At = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
      function It(t) {
        let e = /* @__PURE__ */ new Set([t]), r = /* @__PURE__ */ new Set(), n = t.match(At);
        if (!n)
          return () => false;
        let a = { major: +n[1], minor: +n[2], patch: +n[3], prerelease: n[4] };
        if (a.prerelease != null)
          return function(l) {
            return l === t;
          };
        function s(_) {
          return r.add(_), false;
        }
        function u(_) {
          return e.add(_), true;
        }
        return function(l) {
          if (e.has(l))
            return true;
          if (r.has(l))
            return false;
          let p = l.match(At);
          if (!p)
            return s(l);
          let f = { major: +p[1], minor: +p[2], patch: +p[3], prerelease: p[4] };
          return f.prerelease != null || a.major !== f.major ? s(l) : a.major === 0 ? a.minor === f.minor && a.patch <= f.patch ? u(l) : s(l) : a.minor <= f.minor ? u(l) : s(l);
        };
      }
      R._makeCompatibilityCheck = It;
      R.isCompatible = It(Ur.VERSION);
    });
    var S = i((E) => {
      "use strict";
      Object.defineProperty(E, "__esModule", { value: true });
      E.unregisterGlobal = E.getGlobal = E.registerGlobal = void 0;
      var Fr = Ct(), C = ke(), kr = mt(), $r = C.VERSION.split(".")[0], q = Symbol.for(`opentelemetry.js.api.${$r}`), G = Fr._globalThis;
      function Kr(t, e, r, n = false) {
        var a;
        let s = G[q] = (a = G[q]) !== null && a !== void 0 ? a : { version: C.VERSION };
        if (!n && s[t]) {
          let u = new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${t}`);
          return r.error(u.stack || u.message), false;
        }
        if (s.version !== C.VERSION) {
          let u = new Error(`@opentelemetry/api: Registration of version v${s.version} for ${t} does not match previously registered API v${C.VERSION}`);
          return r.error(u.stack || u.message), false;
        }
        return s[t] = e, r.debug(`@opentelemetry/api: Registered a global for ${t} v${C.VERSION}.`), true;
      }
      E.registerGlobal = Kr;
      function Xr(t) {
        var e, r;
        let n = (e = G[q]) === null || e === void 0 ? void 0 : e.version;
        if (!(!n || !(0, kr.isCompatible)(n)))
          return (r = G[q]) === null || r === void 0 ? void 0 : r[t];
      }
      E.getGlobal = Xr;
      function Wr(t, e) {
        e.debug(`@opentelemetry/api: Unregistering a global for ${t} v${C.VERSION}.`);
        let r = G[q];
        r && delete r[t];
      }
      E.unregisterGlobal = Wr;
    });
    var ht = i((oe) => {
      "use strict";
      Object.defineProperty(oe, "__esModule", { value: true });
      oe.DiagComponentLogger = void 0;
      var Yr = S(), $e = class {
        constructor(e) {
          this._namespace = e.namespace || "DiagComponentLogger";
        }
        debug(...e) {
          return B("debug", this._namespace, e);
        }
        error(...e) {
          return B("error", this._namespace, e);
        }
        info(...e) {
          return B("info", this._namespace, e);
        }
        warn(...e) {
          return B("warn", this._namespace, e);
        }
        verbose(...e) {
          return B("verbose", this._namespace, e);
        }
      };
      oe.DiagComponentLogger = $e;
      function B(t, e, r) {
        let n = (0, Yr.getGlobal)("diag");
        if (n)
          return r.unshift(e), n[t](...r);
      }
    });
    var ie = i((U) => {
      "use strict";
      Object.defineProperty(U, "__esModule", { value: true });
      U.DiagLogLevel = void 0;
      var Hr;
      (function(t) {
        t[t.NONE = 0] = "NONE", t[t.ERROR = 30] = "ERROR", t[t.WARN = 50] = "WARN", t[t.INFO = 60] = "INFO", t[t.DEBUG = 70] = "DEBUG", t[t.VERBOSE = 80] = "VERBOSE", t[t.ALL = 9999] = "ALL";
      })(Hr = U.DiagLogLevel || (U.DiagLogLevel = {}));
    });
    var xt = i((se) => {
      "use strict";
      Object.defineProperty(se, "__esModule", { value: true });
      se.createLogLevelDiagLogger = void 0;
      var P = ie();
      function zr(t, e) {
        t < P.DiagLogLevel.NONE ? t = P.DiagLogLevel.NONE : t > P.DiagLogLevel.ALL && (t = P.DiagLogLevel.ALL), e = e || {};
        function r(n, a) {
          let s = e[n];
          return typeof s == "function" && t >= a ? s.bind(e) : function() {
          };
        }
        return { error: r("error", P.DiagLogLevel.ERROR), warn: r("warn", P.DiagLogLevel.WARN), info: r("info", P.DiagLogLevel.INFO), debug: r("debug", P.DiagLogLevel.DEBUG), verbose: r("verbose", P.DiagLogLevel.VERBOSE) };
      }
      se.createLogLevelDiagLogger = zr;
    });
    var M = i((ue) => {
      "use strict";
      Object.defineProperty(ue, "__esModule", { value: true });
      ue.DiagAPI = void 0;
      var Qr = ht(), Jr = xt(), Dt = ie(), ce = S(), Zr = "diag", F = class {
        constructor() {
          function e(a) {
            return function(...s) {
              let u = (0, ce.getGlobal)("diag");
              if (u)
                return u[a](...s);
            };
          }
          let r = this, n = (a, s = { logLevel: Dt.DiagLogLevel.INFO }) => {
            var u, _, l;
            if (a === r) {
              let w = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
              return r.error((u = w.stack) !== null && u !== void 0 ? u : w.message), false;
            }
            typeof s == "number" && (s = { logLevel: s });
            let p = (0, ce.getGlobal)("diag"), f = (0, Jr.createLogLevelDiagLogger)((_ = s.logLevel) !== null && _ !== void 0 ? _ : Dt.DiagLogLevel.INFO, a);
            if (p && !s.suppressOverrideMessage) {
              let w = (l = new Error().stack) !== null && l !== void 0 ? l : "<failed to generate stacktrace>";
              p.warn(`Current logger will be overwritten from ${w}`), f.warn(`Current logger will overwrite one already registered from ${w}`);
            }
            return (0, ce.registerGlobal)("diag", f, r, true);
          };
          r.setLogger = n, r.disable = () => {
            (0, ce.unregisterGlobal)(Zr, r);
          }, r.createComponentLogger = (a) => new Qr.DiagComponentLogger(a), r.verbose = e("verbose"), r.debug = e("debug"), r.info = e("info"), r.warn = e("warn"), r.error = e("error");
        }
        static instance() {
          return this._instance || (this._instance = new F()), this._instance;
        }
      };
      ue.DiagAPI = F;
    });
    var jt = i((le) => {
      "use strict";
      Object.defineProperty(le, "__esModule", { value: true });
      le.BaggageImpl = void 0;
      var T = class {
        constructor(e) {
          this._entries = e ? new Map(e) : /* @__PURE__ */ new Map();
        }
        getEntry(e) {
          let r = this._entries.get(e);
          if (r)
            return Object.assign({}, r);
        }
        getAllEntries() {
          return Array.from(this._entries.entries()).map(([e, r]) => [e, r]);
        }
        setEntry(e, r) {
          let n = new T(this._entries);
          return n._entries.set(e, r), n;
        }
        removeEntry(e) {
          let r = new T(this._entries);
          return r._entries.delete(e), r;
        }
        removeEntries(...e) {
          let r = new T(this._entries);
          for (let n of e)
            r._entries.delete(n);
          return r;
        }
        clear() {
          return new T();
        }
      };
      le.BaggageImpl = T;
    });
    var Lt = i((_e) => {
      "use strict";
      Object.defineProperty(_e, "__esModule", { value: true });
      _e.baggageEntryMetadataSymbol = void 0;
      _e.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
    });
    var Ke = i((A) => {
      "use strict";
      Object.defineProperty(A, "__esModule", { value: true });
      A.baggageEntryMetadataFromString = A.createBaggage = void 0;
      var en = M(), tn = jt(), rn = Lt(), nn = en.DiagAPI.instance();
      function an(t = {}) {
        return new tn.BaggageImpl(new Map(Object.entries(t)));
      }
      A.createBaggage = an;
      function on(t) {
        return typeof t != "string" && (nn.error(`Cannot create baggage metadata from unknown type: ${typeof t}`), t = ""), { __TYPE__: rn.baggageEntryMetadataSymbol, toString() {
          return t;
        } };
      }
      A.baggageEntryMetadataFromString = on;
    });
    var k = i((m) => {
      "use strict";
      Object.defineProperty(m, "__esModule", { value: true });
      m.ROOT_CONTEXT = m.createContextKey = void 0;
      function sn(t) {
        return Symbol.for(t);
      }
      m.createContextKey = sn;
      var I = class {
        constructor(e) {
          let r = this;
          r._currentContext = e ? new Map(e) : /* @__PURE__ */ new Map(), r.getValue = (n) => r._currentContext.get(n), r.setValue = (n, a) => {
            let s = new I(r._currentContext);
            return s._currentContext.set(n, a), s;
          }, r.deleteValue = (n) => {
            let a = new I(r._currentContext);
            return a._currentContext.delete(n), a;
          };
        }
      };
      m.ROOT_CONTEXT = new I();
    });
    var Vt = i((ge) => {
      "use strict";
      Object.defineProperty(ge, "__esModule", { value: true });
      ge.DiagConsoleLogger = void 0;
      var Xe = [{ n: "error", c: "error" }, { n: "warn", c: "warn" }, { n: "info", c: "info" }, { n: "debug", c: "debug" }, { n: "verbose", c: "trace" }], We = class {
        constructor() {
          function e(r) {
            return function(...n) {
              if (console) {
                let a = console[r];
                if (typeof a != "function" && (a = console.log), typeof a == "function")
                  return a.apply(console, n);
              }
            };
          }
          for (let r = 0; r < Xe.length; r++)
            this[Xe[r].n] = e(Xe[r].c);
        }
      };
      ge.DiagConsoleLogger = We;
    });
    var Ye = i((c) => {
      "use strict";
      Object.defineProperty(c, "__esModule", { value: true });
      c.createNoopMeter = c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = c.NOOP_OBSERVABLE_GAUGE_METRIC = c.NOOP_OBSERVABLE_COUNTER_METRIC = c.NOOP_UP_DOWN_COUNTER_METRIC = c.NOOP_HISTOGRAM_METRIC = c.NOOP_COUNTER_METRIC = c.NOOP_METER = c.NoopObservableUpDownCounterMetric = c.NoopObservableGaugeMetric = c.NoopObservableCounterMetric = c.NoopObservableMetric = c.NoopHistogramMetric = c.NoopUpDownCounterMetric = c.NoopCounterMetric = c.NoopMetric = c.NoopMeter = void 0;
      var de = class {
        constructor() {
        }
        createHistogram(e, r) {
          return c.NOOP_HISTOGRAM_METRIC;
        }
        createCounter(e, r) {
          return c.NOOP_COUNTER_METRIC;
        }
        createUpDownCounter(e, r) {
          return c.NOOP_UP_DOWN_COUNTER_METRIC;
        }
        createObservableGauge(e, r) {
          return c.NOOP_OBSERVABLE_GAUGE_METRIC;
        }
        createObservableCounter(e, r) {
          return c.NOOP_OBSERVABLE_COUNTER_METRIC;
        }
        createObservableUpDownCounter(e, r) {
          return c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
        }
        addBatchObservableCallback(e, r) {
        }
        removeBatchObservableCallback(e) {
        }
      };
      c.NoopMeter = de;
      var h = class {
      };
      c.NoopMetric = h;
      var pe = class extends h {
        add(e, r) {
        }
      };
      c.NoopCounterMetric = pe;
      var fe = class extends h {
        add(e, r) {
        }
      };
      c.NoopUpDownCounterMetric = fe;
      var Oe = class extends h {
        record(e, r) {
        }
      };
      c.NoopHistogramMetric = Oe;
      var x = class {
        addCallback(e) {
        }
        removeCallback(e) {
        }
      };
      c.NoopObservableMetric = x;
      var be = class extends x {
      };
      c.NoopObservableCounterMetric = be;
      var ve = class extends x {
      };
      c.NoopObservableGaugeMetric = ve;
      var Pe = class extends x {
      };
      c.NoopObservableUpDownCounterMetric = Pe;
      c.NOOP_METER = new de();
      c.NOOP_COUNTER_METRIC = new pe();
      c.NOOP_HISTOGRAM_METRIC = new Oe();
      c.NOOP_UP_DOWN_COUNTER_METRIC = new fe();
      c.NOOP_OBSERVABLE_COUNTER_METRIC = new be();
      c.NOOP_OBSERVABLE_GAUGE_METRIC = new ve();
      c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new Pe();
      function cn() {
        return c.NOOP_METER;
      }
      c.createNoopMeter = cn;
    });
    var wt = i(($) => {
      "use strict";
      Object.defineProperty($, "__esModule", { value: true });
      $.ValueType = void 0;
      var un;
      (function(t) {
        t[t.INT = 0] = "INT", t[t.DOUBLE = 1] = "DOUBLE";
      })(un = $.ValueType || ($.ValueType = {}));
    });
    var He = i((D) => {
      "use strict";
      Object.defineProperty(D, "__esModule", { value: true });
      D.defaultTextMapSetter = D.defaultTextMapGetter = void 0;
      D.defaultTextMapGetter = { get(t, e) {
        if (t != null)
          return t[e];
      }, keys(t) {
        return t == null ? [] : Object.keys(t);
      } };
      D.defaultTextMapSetter = { set(t, e, r) {
        t != null && (t[e] = r);
      } };
    });
    var qt = i((Ee) => {
      "use strict";
      Object.defineProperty(Ee, "__esModule", { value: true });
      Ee.NoopContextManager = void 0;
      var ln = k(), ze = class {
        active() {
          return ln.ROOT_CONTEXT;
        }
        with(e, r, n, ...a) {
          return r.call(n, ...a);
        }
        bind(e, r) {
          return r;
        }
        enable() {
          return this;
        }
        disable() {
          return this;
        }
      };
      Ee.NoopContextManager = ze;
    });
    var X = i((Te) => {
      "use strict";
      Object.defineProperty(Te, "__esModule", { value: true });
      Te.ContextAPI = void 0;
      var _n = qt(), Qe = S(), Gt = M(), Je = "context", gn = new _n.NoopContextManager(), K = class {
        constructor() {
        }
        static getInstance() {
          return this._instance || (this._instance = new K()), this._instance;
        }
        setGlobalContextManager(e) {
          return (0, Qe.registerGlobal)(Je, e, Gt.DiagAPI.instance());
        }
        active() {
          return this._getContextManager().active();
        }
        with(e, r, n, ...a) {
          return this._getContextManager().with(e, r, n, ...a);
        }
        bind(e, r) {
          return this._getContextManager().bind(e, r);
        }
        _getContextManager() {
          return (0, Qe.getGlobal)(Je) || gn;
        }
        disable() {
          this._getContextManager().disable(), (0, Qe.unregisterGlobal)(Je, Gt.DiagAPI.instance());
        }
      };
      Te.ContextAPI = K;
    });
    var Ze = i((W) => {
      "use strict";
      Object.defineProperty(W, "__esModule", { value: true });
      W.TraceFlags = void 0;
      var dn;
      (function(t) {
        t[t.NONE = 0] = "NONE", t[t.SAMPLED = 1] = "SAMPLED";
      })(dn = W.TraceFlags || (W.TraceFlags = {}));
    });
    var Ne = i((O) => {
      "use strict";
      Object.defineProperty(O, "__esModule", { value: true });
      O.INVALID_SPAN_CONTEXT = O.INVALID_TRACEID = O.INVALID_SPANID = void 0;
      var pn = Ze();
      O.INVALID_SPANID = "0000000000000000";
      O.INVALID_TRACEID = "00000000000000000000000000000000";
      O.INVALID_SPAN_CONTEXT = { traceId: O.INVALID_TRACEID, spanId: O.INVALID_SPANID, traceFlags: pn.TraceFlags.NONE };
    });
    var Se = i((ye) => {
      "use strict";
      Object.defineProperty(ye, "__esModule", { value: true });
      ye.NonRecordingSpan = void 0;
      var fn = Ne(), et = class {
        constructor(e = fn.INVALID_SPAN_CONTEXT) {
          this._spanContext = e;
        }
        spanContext() {
          return this._spanContext;
        }
        setAttribute(e, r) {
          return this;
        }
        setAttributes(e) {
          return this;
        }
        addEvent(e, r) {
          return this;
        }
        setStatus(e) {
          return this;
        }
        updateName(e) {
          return this;
        }
        end(e) {
        }
        isRecording() {
          return false;
        }
        recordException(e, r) {
        }
      };
      ye.NonRecordingSpan = et;
    });
    var nt = i((d) => {
      "use strict";
      Object.defineProperty(d, "__esModule", { value: true });
      d.getSpanContext = d.setSpanContext = d.deleteSpan = d.setSpan = d.getActiveSpan = d.getSpan = void 0;
      var On = k(), bn = Se(), vn = X(), tt = (0, On.createContextKey)("OpenTelemetry Context Key SPAN");
      function rt(t) {
        return t.getValue(tt) || void 0;
      }
      d.getSpan = rt;
      function Pn() {
        return rt(vn.ContextAPI.getInstance().active());
      }
      d.getActiveSpan = Pn;
      function Bt(t, e) {
        return t.setValue(tt, e);
      }
      d.setSpan = Bt;
      function En(t) {
        return t.deleteValue(tt);
      }
      d.deleteSpan = En;
      function Tn(t, e) {
        return Bt(t, new bn.NonRecordingSpan(e));
      }
      d.setSpanContext = Tn;
      function Nn(t) {
        var e;
        return (e = rt(t)) === null || e === void 0 ? void 0 : e.spanContext();
      }
      d.getSpanContext = Nn;
    });
    var Me = i((b) => {
      "use strict";
      Object.defineProperty(b, "__esModule", { value: true });
      b.wrapSpanContext = b.isSpanContextValid = b.isValidSpanId = b.isValidTraceId = void 0;
      var Ut = Ne(), yn = Se(), Sn = /^([0-9a-f]{32})$/i, Mn = /^[0-9a-f]{16}$/i;
      function Ft(t) {
        return Sn.test(t) && t !== Ut.INVALID_TRACEID;
      }
      b.isValidTraceId = Ft;
      function kt(t) {
        return Mn.test(t) && t !== Ut.INVALID_SPANID;
      }
      b.isValidSpanId = kt;
      function Rn(t) {
        return Ft(t.traceId) && kt(t.spanId);
      }
      b.isSpanContextValid = Rn;
      function Cn(t) {
        return new yn.NonRecordingSpan(t);
      }
      b.wrapSpanContext = Cn;
    });
    var st = i((Re) => {
      "use strict";
      Object.defineProperty(Re, "__esModule", { value: true });
      Re.NoopTracer = void 0;
      var An = X(), $t = nt(), at = Se(), In = Me(), ot = An.ContextAPI.getInstance(), it = class {
        startSpan(e, r, n = ot.active()) {
          if (!!(r != null && r.root))
            return new at.NonRecordingSpan();
          let s = n && (0, $t.getSpanContext)(n);
          return mn(s) && (0, In.isSpanContextValid)(s) ? new at.NonRecordingSpan(s) : new at.NonRecordingSpan();
        }
        startActiveSpan(e, r, n, a) {
          let s, u, _;
          if (arguments.length < 2)
            return;
          arguments.length === 2 ? _ = r : arguments.length === 3 ? (s = r, _ = n) : (s = r, u = n, _ = a);
          let l = u ?? ot.active(), p = this.startSpan(e, s, l), f = (0, $t.setSpan)(l, p);
          return ot.with(f, _, void 0, p);
        }
      };
      Re.NoopTracer = it;
      function mn(t) {
        return typeof t == "object" && typeof t.spanId == "string" && typeof t.traceId == "string" && typeof t.traceFlags == "number";
      }
    });
    var ut = i((Ce) => {
      "use strict";
      Object.defineProperty(Ce, "__esModule", { value: true });
      Ce.ProxyTracer = void 0;
      var hn = st(), xn = new hn.NoopTracer(), ct = class {
        constructor(e, r, n, a) {
          this._provider = e, this.name = r, this.version = n, this.options = a;
        }
        startSpan(e, r, n) {
          return this._getTracer().startSpan(e, r, n);
        }
        startActiveSpan(e, r, n, a) {
          let s = this._getTracer();
          return Reflect.apply(s.startActiveSpan, s, arguments);
        }
        _getTracer() {
          if (this._delegate)
            return this._delegate;
          let e = this._provider.getDelegateTracer(this.name, this.version, this.options);
          return e ? (this._delegate = e, this._delegate) : xn;
        }
      };
      Ce.ProxyTracer = ct;
    });
    var Kt = i((Ae) => {
      "use strict";
      Object.defineProperty(Ae, "__esModule", { value: true });
      Ae.NoopTracerProvider = void 0;
      var Dn = st(), lt = class {
        getTracer(e, r, n) {
          return new Dn.NoopTracer();
        }
      };
      Ae.NoopTracerProvider = lt;
    });
    var gt = i((Ie) => {
      "use strict";
      Object.defineProperty(Ie, "__esModule", { value: true });
      Ie.ProxyTracerProvider = void 0;
      var jn = ut(), Ln = Kt(), Vn = new Ln.NoopTracerProvider(), _t = class {
        getTracer(e, r, n) {
          var a;
          return (a = this.getDelegateTracer(e, r, n)) !== null && a !== void 0 ? a : new jn.ProxyTracer(this, e, r, n);
        }
        getDelegate() {
          var e;
          return (e = this._delegate) !== null && e !== void 0 ? e : Vn;
        }
        setDelegate(e) {
          this._delegate = e;
        }
        getDelegateTracer(e, r, n) {
          var a;
          return (a = this._delegate) === null || a === void 0 ? void 0 : a.getTracer(e, r, n);
        }
      };
      Ie.ProxyTracerProvider = _t;
    });
    var Xt = i((Y) => {
      "use strict";
      Object.defineProperty(Y, "__esModule", { value: true });
      Y.SamplingDecision = void 0;
      var wn;
      (function(t) {
        t[t.NOT_RECORD = 0] = "NOT_RECORD", t[t.RECORD = 1] = "RECORD", t[t.RECORD_AND_SAMPLED = 2] = "RECORD_AND_SAMPLED";
      })(wn = Y.SamplingDecision || (Y.SamplingDecision = {}));
    });
    var Wt = i((H) => {
      "use strict";
      Object.defineProperty(H, "__esModule", { value: true });
      H.SpanKind = void 0;
      var qn;
      (function(t) {
        t[t.INTERNAL = 0] = "INTERNAL", t[t.SERVER = 1] = "SERVER", t[t.CLIENT = 2] = "CLIENT", t[t.PRODUCER = 3] = "PRODUCER", t[t.CONSUMER = 4] = "CONSUMER";
      })(qn = H.SpanKind || (H.SpanKind = {}));
    });
    var Yt = i((z) => {
      "use strict";
      Object.defineProperty(z, "__esModule", { value: true });
      z.SpanStatusCode = void 0;
      var Gn;
      (function(t) {
        t[t.UNSET = 0] = "UNSET", t[t.OK = 1] = "OK", t[t.ERROR = 2] = "ERROR";
      })(Gn = z.SpanStatusCode || (z.SpanStatusCode = {}));
    });
    var Ht = i((j) => {
      "use strict";
      Object.defineProperty(j, "__esModule", { value: true });
      j.validateValue = j.validateKey = void 0;
      var dt = "[_0-9a-z-*/]", Bn = `[a-z]${dt}{0,255}`, Un = `[a-z0-9]${dt}{0,240}@[a-z]${dt}{0,13}`, Fn = new RegExp(`^(?:${Bn}|${Un})$`), kn = /^[ -~]{0,255}[!-~]$/, $n = /,|=/;
      function Kn(t) {
        return Fn.test(t);
      }
      j.validateKey = Kn;
      function Xn(t) {
        return kn.test(t) && !$n.test(t);
      }
      j.validateValue = Xn;
    });
    var er = i((me) => {
      "use strict";
      Object.defineProperty(me, "__esModule", { value: true });
      me.TraceStateImpl = void 0;
      var zt = Ht(), Qt = 32, Wn = 512, Jt = ",", Zt = "=", Q = class {
        constructor(e) {
          this._internalState = /* @__PURE__ */ new Map(), e && this._parse(e);
        }
        set(e, r) {
          let n = this._clone();
          return n._internalState.has(e) && n._internalState.delete(e), n._internalState.set(e, r), n;
        }
        unset(e) {
          let r = this._clone();
          return r._internalState.delete(e), r;
        }
        get(e) {
          return this._internalState.get(e);
        }
        serialize() {
          return this._keys().reduce((e, r) => (e.push(r + Zt + this.get(r)), e), []).join(Jt);
        }
        _parse(e) {
          e.length > Wn || (this._internalState = e.split(Jt).reverse().reduce((r, n) => {
            let a = n.trim(), s = a.indexOf(Zt);
            if (s !== -1) {
              let u = a.slice(0, s), _ = a.slice(s + 1, n.length);
              (0, zt.validateKey)(u) && (0, zt.validateValue)(_) && r.set(u, _);
            }
            return r;
          }, /* @__PURE__ */ new Map()), this._internalState.size > Qt && (this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, Qt))));
        }
        _keys() {
          return Array.from(this._internalState.keys()).reverse();
        }
        _clone() {
          let e = new Q();
          return e._internalState = new Map(this._internalState), e;
        }
      };
      me.TraceStateImpl = Q;
    });
    var tr = i((he) => {
      "use strict";
      Object.defineProperty(he, "__esModule", { value: true });
      he.createTraceState = void 0;
      var Yn = er();
      function Hn(t) {
        return new Yn.TraceStateImpl(t);
      }
      he.createTraceState = Hn;
    });
    var rr = i((xe) => {
      "use strict";
      Object.defineProperty(xe, "__esModule", { value: true });
      xe.context = void 0;
      var zn = X();
      xe.context = zn.ContextAPI.getInstance();
    });
    var nr = i((De) => {
      "use strict";
      Object.defineProperty(De, "__esModule", { value: true });
      De.diag = void 0;
      var Qn = M();
      De.diag = Qn.DiagAPI.instance();
    });
    var ar = i((L) => {
      "use strict";
      Object.defineProperty(L, "__esModule", { value: true });
      L.NOOP_METER_PROVIDER = L.NoopMeterProvider = void 0;
      var Jn = Ye(), je = class {
        getMeter(e, r, n) {
          return Jn.NOOP_METER;
        }
      };
      L.NoopMeterProvider = je;
      L.NOOP_METER_PROVIDER = new je();
    });
    var ir = i((Le) => {
      "use strict";
      Object.defineProperty(Le, "__esModule", { value: true });
      Le.MetricsAPI = void 0;
      var Zn = ar(), pt = S(), or = M(), ft = "metrics", J = class {
        constructor() {
        }
        static getInstance() {
          return this._instance || (this._instance = new J()), this._instance;
        }
        setGlobalMeterProvider(e) {
          return (0, pt.registerGlobal)(ft, e, or.DiagAPI.instance());
        }
        getMeterProvider() {
          return (0, pt.getGlobal)(ft) || Zn.NOOP_METER_PROVIDER;
        }
        getMeter(e, r, n) {
          return this.getMeterProvider().getMeter(e, r, n);
        }
        disable() {
          (0, pt.unregisterGlobal)(ft, or.DiagAPI.instance());
        }
      };
      Le.MetricsAPI = J;
    });
    var sr = i((Ve) => {
      "use strict";
      Object.defineProperty(Ve, "__esModule", { value: true });
      Ve.metrics = void 0;
      var ea = ir();
      Ve.metrics = ea.MetricsAPI.getInstance();
    });
    var cr = i((we) => {
      "use strict";
      Object.defineProperty(we, "__esModule", { value: true });
      we.NoopTextMapPropagator = void 0;
      var Ot = class {
        inject(e, r) {
        }
        extract(e, r) {
          return e;
        }
        fields() {
          return [];
        }
      };
      we.NoopTextMapPropagator = Ot;
    });
    var lr = i((v) => {
      "use strict";
      Object.defineProperty(v, "__esModule", { value: true });
      v.deleteBaggage = v.setBaggage = v.getActiveBaggage = v.getBaggage = void 0;
      var ta = X(), ra = k(), bt = (0, ra.createContextKey)("OpenTelemetry Baggage Key");
      function ur(t) {
        return t.getValue(bt) || void 0;
      }
      v.getBaggage = ur;
      function na() {
        return ur(ta.ContextAPI.getInstance().active());
      }
      v.getActiveBaggage = na;
      function aa(t, e) {
        return t.setValue(bt, e);
      }
      v.setBaggage = aa;
      function oa(t) {
        return t.deleteValue(bt);
      }
      v.deleteBaggage = oa;
    });
    var dr = i((Ge) => {
      "use strict";
      Object.defineProperty(Ge, "__esModule", { value: true });
      Ge.PropagationAPI = void 0;
      var vt = S(), ia = cr(), _r = He(), qe = lr(), sa = Ke(), gr = M(), Pt = "propagation", ca = new ia.NoopTextMapPropagator(), Z = class {
        constructor() {
          this.createBaggage = sa.createBaggage, this.getBaggage = qe.getBaggage, this.getActiveBaggage = qe.getActiveBaggage, this.setBaggage = qe.setBaggage, this.deleteBaggage = qe.deleteBaggage;
        }
        static getInstance() {
          return this._instance || (this._instance = new Z()), this._instance;
        }
        setGlobalPropagator(e) {
          return (0, vt.registerGlobal)(Pt, e, gr.DiagAPI.instance());
        }
        inject(e, r, n = _r.defaultTextMapSetter) {
          return this._getGlobalPropagator().inject(e, r, n);
        }
        extract(e, r, n = _r.defaultTextMapGetter) {
          return this._getGlobalPropagator().extract(e, r, n);
        }
        fields() {
          return this._getGlobalPropagator().fields();
        }
        disable() {
          (0, vt.unregisterGlobal)(Pt, gr.DiagAPI.instance());
        }
        _getGlobalPropagator() {
          return (0, vt.getGlobal)(Pt) || ca;
        }
      };
      Ge.PropagationAPI = Z;
    });
    var pr = i((Be) => {
      "use strict";
      Object.defineProperty(Be, "__esModule", { value: true });
      Be.propagation = void 0;
      var ua = dr();
      Be.propagation = ua.PropagationAPI.getInstance();
    });
    var vr = i((Ue) => {
      "use strict";
      Object.defineProperty(Ue, "__esModule", { value: true });
      Ue.TraceAPI = void 0;
      var Et = S(), fr = gt(), Or = Me(), V = nt(), br = M(), Tt = "trace", ee = class {
        constructor() {
          this._proxyTracerProvider = new fr.ProxyTracerProvider(), this.wrapSpanContext = Or.wrapSpanContext, this.isSpanContextValid = Or.isSpanContextValid, this.deleteSpan = V.deleteSpan, this.getSpan = V.getSpan, this.getActiveSpan = V.getActiveSpan, this.getSpanContext = V.getSpanContext, this.setSpan = V.setSpan, this.setSpanContext = V.setSpanContext;
        }
        static getInstance() {
          return this._instance || (this._instance = new ee()), this._instance;
        }
        setGlobalTracerProvider(e) {
          let r = (0, Et.registerGlobal)(Tt, this._proxyTracerProvider, br.DiagAPI.instance());
          return r && this._proxyTracerProvider.setDelegate(e), r;
        }
        getTracerProvider() {
          return (0, Et.getGlobal)(Tt) || this._proxyTracerProvider;
        }
        getTracer(e, r) {
          return this.getTracerProvider().getTracer(e, r);
        }
        disable() {
          (0, Et.unregisterGlobal)(Tt, br.DiagAPI.instance()), this._proxyTracerProvider = new fr.ProxyTracerProvider();
        }
      };
      Ue.TraceAPI = ee;
    });
    var Pr = i((Fe) => {
      "use strict";
      Object.defineProperty(Fe, "__esModule", { value: true });
      Fe.trace = void 0;
      var la = vr();
      Fe.trace = la.TraceAPI.getInstance();
    });
    var Cr = i((o) => {
      "use strict";
      Object.defineProperty(o, "__esModule", { value: true });
      o.trace = o.propagation = o.metrics = o.diag = o.context = o.INVALID_SPAN_CONTEXT = o.INVALID_TRACEID = o.INVALID_SPANID = o.isValidSpanId = o.isValidTraceId = o.isSpanContextValid = o.createTraceState = o.TraceFlags = o.SpanStatusCode = o.SpanKind = o.SamplingDecision = o.ProxyTracerProvider = o.ProxyTracer = o.defaultTextMapSetter = o.defaultTextMapGetter = o.ValueType = o.createNoopMeter = o.DiagLogLevel = o.DiagConsoleLogger = o.ROOT_CONTEXT = o.createContextKey = o.baggageEntryMetadataFromString = void 0;
      var _a = Ke();
      Object.defineProperty(o, "baggageEntryMetadataFromString", { enumerable: true, get: function() {
        return _a.baggageEntryMetadataFromString;
      } });
      var Er = k();
      Object.defineProperty(o, "createContextKey", { enumerable: true, get: function() {
        return Er.createContextKey;
      } });
      Object.defineProperty(o, "ROOT_CONTEXT", { enumerable: true, get: function() {
        return Er.ROOT_CONTEXT;
      } });
      var ga = Vt();
      Object.defineProperty(o, "DiagConsoleLogger", { enumerable: true, get: function() {
        return ga.DiagConsoleLogger;
      } });
      var da = ie();
      Object.defineProperty(o, "DiagLogLevel", { enumerable: true, get: function() {
        return da.DiagLogLevel;
      } });
      var pa = Ye();
      Object.defineProperty(o, "createNoopMeter", { enumerable: true, get: function() {
        return pa.createNoopMeter;
      } });
      var fa = wt();
      Object.defineProperty(o, "ValueType", { enumerable: true, get: function() {
        return fa.ValueType;
      } });
      var Tr = He();
      Object.defineProperty(o, "defaultTextMapGetter", { enumerable: true, get: function() {
        return Tr.defaultTextMapGetter;
      } });
      Object.defineProperty(o, "defaultTextMapSetter", { enumerable: true, get: function() {
        return Tr.defaultTextMapSetter;
      } });
      var Oa = ut();
      Object.defineProperty(o, "ProxyTracer", { enumerable: true, get: function() {
        return Oa.ProxyTracer;
      } });
      var ba = gt();
      Object.defineProperty(o, "ProxyTracerProvider", { enumerable: true, get: function() {
        return ba.ProxyTracerProvider;
      } });
      var va = Xt();
      Object.defineProperty(o, "SamplingDecision", { enumerable: true, get: function() {
        return va.SamplingDecision;
      } });
      var Pa = Wt();
      Object.defineProperty(o, "SpanKind", { enumerable: true, get: function() {
        return Pa.SpanKind;
      } });
      var Ea = Yt();
      Object.defineProperty(o, "SpanStatusCode", { enumerable: true, get: function() {
        return Ea.SpanStatusCode;
      } });
      var Ta = Ze();
      Object.defineProperty(o, "TraceFlags", { enumerable: true, get: function() {
        return Ta.TraceFlags;
      } });
      var Na = tr();
      Object.defineProperty(o, "createTraceState", { enumerable: true, get: function() {
        return Na.createTraceState;
      } });
      var Nt = Me();
      Object.defineProperty(o, "isSpanContextValid", { enumerable: true, get: function() {
        return Nt.isSpanContextValid;
      } });
      Object.defineProperty(o, "isValidTraceId", { enumerable: true, get: function() {
        return Nt.isValidTraceId;
      } });
      Object.defineProperty(o, "isValidSpanId", { enumerable: true, get: function() {
        return Nt.isValidSpanId;
      } });
      var yt = Ne();
      Object.defineProperty(o, "INVALID_SPANID", { enumerable: true, get: function() {
        return yt.INVALID_SPANID;
      } });
      Object.defineProperty(o, "INVALID_TRACEID", { enumerable: true, get: function() {
        return yt.INVALID_TRACEID;
      } });
      Object.defineProperty(o, "INVALID_SPAN_CONTEXT", { enumerable: true, get: function() {
        return yt.INVALID_SPAN_CONTEXT;
      } });
      var Nr = rr();
      Object.defineProperty(o, "context", { enumerable: true, get: function() {
        return Nr.context;
      } });
      var yr = nr();
      Object.defineProperty(o, "diag", { enumerable: true, get: function() {
        return yr.diag;
      } });
      var Sr = sr();
      Object.defineProperty(o, "metrics", { enumerable: true, get: function() {
        return Sr.metrics;
      } });
      var Mr = pr();
      Object.defineProperty(o, "propagation", { enumerable: true, get: function() {
        return Mr.propagation;
      } });
      var Rr = Pr();
      Object.defineProperty(o, "trace", { enumerable: true, get: function() {
        return Rr.trace;
      } });
      o.default = { context: Nr.context, diag: yr.diag, metrics: Sr.metrics, propagation: Mr.propagation, trace: Rr.trace };
    });
    var Aa = {};
    jr(Aa, { lambdaWrapper: () => ya });
    module2.exports = Vr(Aa);
    var g = Lr(Cr());
    function te(t, e = "", r = {}) {
      if (e && typeof t == "object" && t !== null && Object.keys(t).length === 0)
        return r[e] = Array.isArray(t) ? [] : {}, r;
      e = e ? `${e}.` : "";
      for (let n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (typeof t[n] == "object" && t[n] !== null ? te(t[n], e + n, r) : r[e + n] = t[n]);
      return r;
    }
    function ya(t) {
      return async (e, r) => {
        let n = g.trace.getTracer("@baselime/baselime-lambda-wrapper", "1"), a = Ra(e);
        console.log(a);
        let s = n.startSpan(r.functionName, { attributes: te({ event: e, context: r, faas: { execution: r.awsRequestId, name: r.functionName, runtime: "nodejs", id: r.invokedFunctionArn }, cloud: { account: { id: r.invokedFunctionArn.split(":")[4] } } }) }, a), u = g.trace.setSpan(g.context.active(), s);
        try {
          let _ = await g.context.with(u, t, null, e, r);
          return s.setAttributes(te(_, "result")), s.end(), _;
        } catch (_) {
          let l = _;
          throw s.recordException(l), s.setAttributes(te({ name: l.name, message: l.message, stack: l.stack }, "error")), s.end(), _;
        } finally {
          baselimeLambdaFlush && (console.log("flushing"), baselimeLambdaFlush());
        }
      };
    }
    function Sa(t) {
      var e, r;
      return (e = t.requestContext) != null && e.apiId ? "api" : t.Records && ((r = t.Records[0]) == null ? void 0 : r.EventSource) === "aws:sns" ? "sns" : "unknown";
    }
    var Ar = { keys(t) {
      return Object.keys(t);
    }, get(t, e) {
      return t[e];
    } };
    var Ma = { keys(t) {
      return Object.keys(t);
    }, get(t, e) {
      var r;
      return (r = t[e]) == null ? void 0 : r.Value;
    } };
    function Ra(t) {
      var n;
      let e, r = Ca(t);
      return (n = g.trace.getSpan(r)) != null && n.spanContext() ? r : e || g.ROOT_CONTEXT;
    }
    function Ca(t) {
      switch (Sa(t)) {
        case "api":
          let e = t.headers || {};
          return g.propagation.extract(g.default.context.active(), e, Ar);
        case "sns":
          return console.log(t.Records[0].Sns.MessageAttributes), g.propagation.extract(g.default.context.active(), t.Records[0].Sns.MessageAttributes, Ma);
      }
      return g.propagation.extract(g.default.context.active(), {}, Ar);
    }
  }
});

// src/utils.js
var utils_exports = {};
__export(utils_exports, {
  flattenObject: () => flattenObject
});
function flattenObject(ob, prefix = "", result = {}) {
  if (prefix && typeof ob === "object" && ob !== null && Object.keys(ob).length === 0) {
    result[prefix] = Array.isArray(ob) ? [] : {};
    return result;
  }
  prefix = prefix ? `${prefix}.` : "";
  for (const i in ob) {
    if (Object.prototype.hasOwnProperty.call(ob, i)) {
      if (typeof ob[i] === "object" && ob[i] !== null) {
        flattenObject(ob[i], prefix + i, result);
      } else {
        result[prefix + i] = ob[i];
      }
    }
  }
  return result;
}
var init_utils = __esm({
  "src/utils.js"() {
    "use strict";
  }
});

// src/main.js
var tiny = require_bundle();
var { context, trace } = require_src();
var { lambdaWrapper: lambdaWrapper2 } = require_lambda_node_opentelemetry();
var { flattenObject: flattenObject2 } = (init_utils(), __toCommonJS(utils_exports));
async function track(name, func, args) {
  const tracer = trace.getTracer(name);
  const attrIn = flattenObject2(args, "name.args");
  const span = tracer.startSpan(name, {
    attributes: attrIn
  });
  const ctx = trace.setSpan(context.active(), span);
  console.log("ctx");
  try {
    const result = await context.with(ctx, func, null, args);
    const attrOut = flattenObject2(result, `${name}.result`);
    span.setAttributes(attrOut);
    span.end();
    return result;
  } catch (e) {
    span.recordException(e);
    span.setAttributes(flattenObject2({ name: e.name, message: e.message, stack: e.stack }, "error"));
    span.end();
    throw e;
  }
}
exports.handler = lambdaWrapper2(async (e) => {
  const { body: customer } = await track("tiny.get", tiny.get, {
    url: `${process.env.API_URL}/hello`
  });
  await track("tiny.post", tiny.post, {
    url: "https://eokl0ly5zia7pe1.m.pipedream.net",
    data: customer
  });
  return customer;
});
