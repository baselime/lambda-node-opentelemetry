"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@baselime/lambda-node-opentelemetry/index.js
var require_lambda_node_opentelemetry = __commonJS({
  "node_modules/@baselime/lambda-node-opentelemetry/index.js"(exports, module2) {
    "use strict";
    var Ir = Object.create;
    var re = Object.defineProperty;
    var mr = Object.getOwnPropertyDescriptor;
    var hr = Object.getOwnPropertyNames;
    var xr = Object.getPrototypeOf;
    var Dr = Object.prototype.hasOwnProperty;
    var i = (t, e) => () => (e || t((e = { exports: {} }).exports, e), e.exports);
    var jr = (t, e) => {
      for (var r in e)
        re(t, r, { get: e[r], enumerable: true });
    };
    var St = (t, e, r, n) => {
      if (e && typeof e == "object" || typeof e == "function")
        for (let a of hr(e))
          !Dr.call(t, a) && a !== r && re(t, a, { get: () => e[a], enumerable: !(n = mr(e, a)) || n.enumerable });
      return t;
    };
    var Lr = (t, e, r) => (r = t != null ? Ir(xr(t)) : {}, St(e || !t || !t.__esModule ? re(r, "default", { value: t, enumerable: true }) : r, t));
    var Vr = (t) => St(re({}, "__esModule", { value: true }), t);
    var Mt = i((ne) => {
      "use strict";
      Object.defineProperty(ne, "__esModule", { value: true });
      ne._globalThis = void 0;
      ne._globalThis = typeof globalThis == "object" ? globalThis : global;
    });
    var Rt = i((N) => {
      "use strict";
      var wr = N && N.__createBinding || (Object.create ? function(t, e, r, n) {
        n === void 0 && (n = r), Object.defineProperty(t, n, { enumerable: true, get: function() {
          return e[r];
        } });
      } : function(t, e, r, n) {
        n === void 0 && (n = r), t[n] = e[r];
      }), qr = N && N.__exportStar || function(t, e) {
        for (var r in t)
          r !== "default" && !Object.prototype.hasOwnProperty.call(e, r) && wr(e, t, r);
      };
      Object.defineProperty(N, "__esModule", { value: true });
      qr(Mt(), N);
    });
    var Ct = i((y) => {
      "use strict";
      var Gr = y && y.__createBinding || (Object.create ? function(t, e, r, n) {
        n === void 0 && (n = r), Object.defineProperty(t, n, { enumerable: true, get: function() {
          return e[r];
        } });
      } : function(t, e, r, n) {
        n === void 0 && (n = r), t[n] = e[r];
      }), Br = y && y.__exportStar || function(t, e) {
        for (var r in t)
          r !== "default" && !Object.prototype.hasOwnProperty.call(e, r) && Gr(e, t, r);
      };
      Object.defineProperty(y, "__esModule", { value: true });
      Br(Rt(), y);
    });
    var ke = i((ae) => {
      "use strict";
      Object.defineProperty(ae, "__esModule", { value: true });
      ae.VERSION = void 0;
      ae.VERSION = "1.4.1";
    });
    var mt = i((R) => {
      "use strict";
      Object.defineProperty(R, "__esModule", { value: true });
      R.isCompatible = R._makeCompatibilityCheck = void 0;
      var Ur = ke(), At = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
      function It(t) {
        let e = /* @__PURE__ */ new Set([t]), r = /* @__PURE__ */ new Set(), n = t.match(At);
        if (!n)
          return () => false;
        let a = { major: +n[1], minor: +n[2], patch: +n[3], prerelease: n[4] };
        if (a.prerelease != null)
          return function(l) {
            return l === t;
          };
        function s(_) {
          return r.add(_), false;
        }
        function u(_) {
          return e.add(_), true;
        }
        return function(l) {
          if (e.has(l))
            return true;
          if (r.has(l))
            return false;
          let p = l.match(At);
          if (!p)
            return s(l);
          let f = { major: +p[1], minor: +p[2], patch: +p[3], prerelease: p[4] };
          return f.prerelease != null || a.major !== f.major ? s(l) : a.major === 0 ? a.minor === f.minor && a.patch <= f.patch ? u(l) : s(l) : a.minor <= f.minor ? u(l) : s(l);
        };
      }
      R._makeCompatibilityCheck = It;
      R.isCompatible = It(Ur.VERSION);
    });
    var S = i((E) => {
      "use strict";
      Object.defineProperty(E, "__esModule", { value: true });
      E.unregisterGlobal = E.getGlobal = E.registerGlobal = void 0;
      var Fr = Ct(), C = ke(), kr = mt(), $r = C.VERSION.split(".")[0], q = Symbol.for(`opentelemetry.js.api.${$r}`), G = Fr._globalThis;
      function Kr(t, e, r, n = false) {
        var a;
        let s = G[q] = (a = G[q]) !== null && a !== void 0 ? a : { version: C.VERSION };
        if (!n && s[t]) {
          let u = new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${t}`);
          return r.error(u.stack || u.message), false;
        }
        if (s.version !== C.VERSION) {
          let u = new Error(`@opentelemetry/api: Registration of version v${s.version} for ${t} does not match previously registered API v${C.VERSION}`);
          return r.error(u.stack || u.message), false;
        }
        return s[t] = e, r.debug(`@opentelemetry/api: Registered a global for ${t} v${C.VERSION}.`), true;
      }
      E.registerGlobal = Kr;
      function Xr(t) {
        var e, r;
        let n = (e = G[q]) === null || e === void 0 ? void 0 : e.version;
        if (!(!n || !(0, kr.isCompatible)(n)))
          return (r = G[q]) === null || r === void 0 ? void 0 : r[t];
      }
      E.getGlobal = Xr;
      function Wr(t, e) {
        e.debug(`@opentelemetry/api: Unregistering a global for ${t} v${C.VERSION}.`);
        let r = G[q];
        r && delete r[t];
      }
      E.unregisterGlobal = Wr;
    });
    var ht = i((oe) => {
      "use strict";
      Object.defineProperty(oe, "__esModule", { value: true });
      oe.DiagComponentLogger = void 0;
      var Yr = S(), $e = class {
        constructor(e) {
          this._namespace = e.namespace || "DiagComponentLogger";
        }
        debug(...e) {
          return B("debug", this._namespace, e);
        }
        error(...e) {
          return B("error", this._namespace, e);
        }
        info(...e) {
          return B("info", this._namespace, e);
        }
        warn(...e) {
          return B("warn", this._namespace, e);
        }
        verbose(...e) {
          return B("verbose", this._namespace, e);
        }
      };
      oe.DiagComponentLogger = $e;
      function B(t, e, r) {
        let n = (0, Yr.getGlobal)("diag");
        if (n)
          return r.unshift(e), n[t](...r);
      }
    });
    var ie = i((U) => {
      "use strict";
      Object.defineProperty(U, "__esModule", { value: true });
      U.DiagLogLevel = void 0;
      var Hr;
      (function(t) {
        t[t.NONE = 0] = "NONE", t[t.ERROR = 30] = "ERROR", t[t.WARN = 50] = "WARN", t[t.INFO = 60] = "INFO", t[t.DEBUG = 70] = "DEBUG", t[t.VERBOSE = 80] = "VERBOSE", t[t.ALL = 9999] = "ALL";
      })(Hr = U.DiagLogLevel || (U.DiagLogLevel = {}));
    });
    var xt = i((se) => {
      "use strict";
      Object.defineProperty(se, "__esModule", { value: true });
      se.createLogLevelDiagLogger = void 0;
      var P = ie();
      function zr(t, e) {
        t < P.DiagLogLevel.NONE ? t = P.DiagLogLevel.NONE : t > P.DiagLogLevel.ALL && (t = P.DiagLogLevel.ALL), e = e || {};
        function r(n, a) {
          let s = e[n];
          return typeof s == "function" && t >= a ? s.bind(e) : function() {
          };
        }
        return { error: r("error", P.DiagLogLevel.ERROR), warn: r("warn", P.DiagLogLevel.WARN), info: r("info", P.DiagLogLevel.INFO), debug: r("debug", P.DiagLogLevel.DEBUG), verbose: r("verbose", P.DiagLogLevel.VERBOSE) };
      }
      se.createLogLevelDiagLogger = zr;
    });
    var M = i((ue) => {
      "use strict";
      Object.defineProperty(ue, "__esModule", { value: true });
      ue.DiagAPI = void 0;
      var Qr = ht(), Jr = xt(), Dt = ie(), ce = S(), Zr = "diag", F = class {
        constructor() {
          function e(a) {
            return function(...s) {
              let u = (0, ce.getGlobal)("diag");
              if (u)
                return u[a](...s);
            };
          }
          let r = this, n = (a, s = { logLevel: Dt.DiagLogLevel.INFO }) => {
            var u, _, l;
            if (a === r) {
              let w = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
              return r.error((u = w.stack) !== null && u !== void 0 ? u : w.message), false;
            }
            typeof s == "number" && (s = { logLevel: s });
            let p = (0, ce.getGlobal)("diag"), f = (0, Jr.createLogLevelDiagLogger)((_ = s.logLevel) !== null && _ !== void 0 ? _ : Dt.DiagLogLevel.INFO, a);
            if (p && !s.suppressOverrideMessage) {
              let w = (l = new Error().stack) !== null && l !== void 0 ? l : "<failed to generate stacktrace>";
              p.warn(`Current logger will be overwritten from ${w}`), f.warn(`Current logger will overwrite one already registered from ${w}`);
            }
            return (0, ce.registerGlobal)("diag", f, r, true);
          };
          r.setLogger = n, r.disable = () => {
            (0, ce.unregisterGlobal)(Zr, r);
          }, r.createComponentLogger = (a) => new Qr.DiagComponentLogger(a), r.verbose = e("verbose"), r.debug = e("debug"), r.info = e("info"), r.warn = e("warn"), r.error = e("error");
        }
        static instance() {
          return this._instance || (this._instance = new F()), this._instance;
        }
      };
      ue.DiagAPI = F;
    });
    var jt = i((le) => {
      "use strict";
      Object.defineProperty(le, "__esModule", { value: true });
      le.BaggageImpl = void 0;
      var T = class {
        constructor(e) {
          this._entries = e ? new Map(e) : /* @__PURE__ */ new Map();
        }
        getEntry(e) {
          let r = this._entries.get(e);
          if (r)
            return Object.assign({}, r);
        }
        getAllEntries() {
          return Array.from(this._entries.entries()).map(([e, r]) => [e, r]);
        }
        setEntry(e, r) {
          let n = new T(this._entries);
          return n._entries.set(e, r), n;
        }
        removeEntry(e) {
          let r = new T(this._entries);
          return r._entries.delete(e), r;
        }
        removeEntries(...e) {
          let r = new T(this._entries);
          for (let n of e)
            r._entries.delete(n);
          return r;
        }
        clear() {
          return new T();
        }
      };
      le.BaggageImpl = T;
    });
    var Lt = i((_e) => {
      "use strict";
      Object.defineProperty(_e, "__esModule", { value: true });
      _e.baggageEntryMetadataSymbol = void 0;
      _e.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
    });
    var Ke = i((A) => {
      "use strict";
      Object.defineProperty(A, "__esModule", { value: true });
      A.baggageEntryMetadataFromString = A.createBaggage = void 0;
      var en = M(), tn = jt(), rn = Lt(), nn = en.DiagAPI.instance();
      function an(t = {}) {
        return new tn.BaggageImpl(new Map(Object.entries(t)));
      }
      A.createBaggage = an;
      function on(t) {
        return typeof t != "string" && (nn.error(`Cannot create baggage metadata from unknown type: ${typeof t}`), t = ""), { __TYPE__: rn.baggageEntryMetadataSymbol, toString() {
          return t;
        } };
      }
      A.baggageEntryMetadataFromString = on;
    });
    var k = i((m) => {
      "use strict";
      Object.defineProperty(m, "__esModule", { value: true });
      m.ROOT_CONTEXT = m.createContextKey = void 0;
      function sn(t) {
        return Symbol.for(t);
      }
      m.createContextKey = sn;
      var I = class {
        constructor(e) {
          let r = this;
          r._currentContext = e ? new Map(e) : /* @__PURE__ */ new Map(), r.getValue = (n) => r._currentContext.get(n), r.setValue = (n, a) => {
            let s = new I(r._currentContext);
            return s._currentContext.set(n, a), s;
          }, r.deleteValue = (n) => {
            let a = new I(r._currentContext);
            return a._currentContext.delete(n), a;
          };
        }
      };
      m.ROOT_CONTEXT = new I();
    });
    var Vt = i((ge) => {
      "use strict";
      Object.defineProperty(ge, "__esModule", { value: true });
      ge.DiagConsoleLogger = void 0;
      var Xe = [{ n: "error", c: "error" }, { n: "warn", c: "warn" }, { n: "info", c: "info" }, { n: "debug", c: "debug" }, { n: "verbose", c: "trace" }], We = class {
        constructor() {
          function e(r) {
            return function(...n) {
              if (console) {
                let a = console[r];
                if (typeof a != "function" && (a = console.log), typeof a == "function")
                  return a.apply(console, n);
              }
            };
          }
          for (let r = 0; r < Xe.length; r++)
            this[Xe[r].n] = e(Xe[r].c);
        }
      };
      ge.DiagConsoleLogger = We;
    });
    var Ye = i((c) => {
      "use strict";
      Object.defineProperty(c, "__esModule", { value: true });
      c.createNoopMeter = c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = c.NOOP_OBSERVABLE_GAUGE_METRIC = c.NOOP_OBSERVABLE_COUNTER_METRIC = c.NOOP_UP_DOWN_COUNTER_METRIC = c.NOOP_HISTOGRAM_METRIC = c.NOOP_COUNTER_METRIC = c.NOOP_METER = c.NoopObservableUpDownCounterMetric = c.NoopObservableGaugeMetric = c.NoopObservableCounterMetric = c.NoopObservableMetric = c.NoopHistogramMetric = c.NoopUpDownCounterMetric = c.NoopCounterMetric = c.NoopMetric = c.NoopMeter = void 0;
      var de = class {
        constructor() {
        }
        createHistogram(e, r) {
          return c.NOOP_HISTOGRAM_METRIC;
        }
        createCounter(e, r) {
          return c.NOOP_COUNTER_METRIC;
        }
        createUpDownCounter(e, r) {
          return c.NOOP_UP_DOWN_COUNTER_METRIC;
        }
        createObservableGauge(e, r) {
          return c.NOOP_OBSERVABLE_GAUGE_METRIC;
        }
        createObservableCounter(e, r) {
          return c.NOOP_OBSERVABLE_COUNTER_METRIC;
        }
        createObservableUpDownCounter(e, r) {
          return c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
        }
        addBatchObservableCallback(e, r) {
        }
        removeBatchObservableCallback(e) {
        }
      };
      c.NoopMeter = de;
      var h = class {
      };
      c.NoopMetric = h;
      var pe = class extends h {
        add(e, r) {
        }
      };
      c.NoopCounterMetric = pe;
      var fe = class extends h {
        add(e, r) {
        }
      };
      c.NoopUpDownCounterMetric = fe;
      var Oe = class extends h {
        record(e, r) {
        }
      };
      c.NoopHistogramMetric = Oe;
      var x = class {
        addCallback(e) {
        }
        removeCallback(e) {
        }
      };
      c.NoopObservableMetric = x;
      var be = class extends x {
      };
      c.NoopObservableCounterMetric = be;
      var ve = class extends x {
      };
      c.NoopObservableGaugeMetric = ve;
      var Pe = class extends x {
      };
      c.NoopObservableUpDownCounterMetric = Pe;
      c.NOOP_METER = new de();
      c.NOOP_COUNTER_METRIC = new pe();
      c.NOOP_HISTOGRAM_METRIC = new Oe();
      c.NOOP_UP_DOWN_COUNTER_METRIC = new fe();
      c.NOOP_OBSERVABLE_COUNTER_METRIC = new be();
      c.NOOP_OBSERVABLE_GAUGE_METRIC = new ve();
      c.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new Pe();
      function cn() {
        return c.NOOP_METER;
      }
      c.createNoopMeter = cn;
    });
    var wt = i(($) => {
      "use strict";
      Object.defineProperty($, "__esModule", { value: true });
      $.ValueType = void 0;
      var un;
      (function(t) {
        t[t.INT = 0] = "INT", t[t.DOUBLE = 1] = "DOUBLE";
      })(un = $.ValueType || ($.ValueType = {}));
    });
    var He = i((D) => {
      "use strict";
      Object.defineProperty(D, "__esModule", { value: true });
      D.defaultTextMapSetter = D.defaultTextMapGetter = void 0;
      D.defaultTextMapGetter = { get(t, e) {
        if (t != null)
          return t[e];
      }, keys(t) {
        return t == null ? [] : Object.keys(t);
      } };
      D.defaultTextMapSetter = { set(t, e, r) {
        t != null && (t[e] = r);
      } };
    });
    var qt = i((Ee) => {
      "use strict";
      Object.defineProperty(Ee, "__esModule", { value: true });
      Ee.NoopContextManager = void 0;
      var ln = k(), ze = class {
        active() {
          return ln.ROOT_CONTEXT;
        }
        with(e, r, n, ...a) {
          return r.call(n, ...a);
        }
        bind(e, r) {
          return r;
        }
        enable() {
          return this;
        }
        disable() {
          return this;
        }
      };
      Ee.NoopContextManager = ze;
    });
    var X = i((Te) => {
      "use strict";
      Object.defineProperty(Te, "__esModule", { value: true });
      Te.ContextAPI = void 0;
      var _n = qt(), Qe = S(), Gt = M(), Je = "context", gn = new _n.NoopContextManager(), K = class {
        constructor() {
        }
        static getInstance() {
          return this._instance || (this._instance = new K()), this._instance;
        }
        setGlobalContextManager(e) {
          return (0, Qe.registerGlobal)(Je, e, Gt.DiagAPI.instance());
        }
        active() {
          return this._getContextManager().active();
        }
        with(e, r, n, ...a) {
          return this._getContextManager().with(e, r, n, ...a);
        }
        bind(e, r) {
          return this._getContextManager().bind(e, r);
        }
        _getContextManager() {
          return (0, Qe.getGlobal)(Je) || gn;
        }
        disable() {
          this._getContextManager().disable(), (0, Qe.unregisterGlobal)(Je, Gt.DiagAPI.instance());
        }
      };
      Te.ContextAPI = K;
    });
    var Ze = i((W) => {
      "use strict";
      Object.defineProperty(W, "__esModule", { value: true });
      W.TraceFlags = void 0;
      var dn;
      (function(t) {
        t[t.NONE = 0] = "NONE", t[t.SAMPLED = 1] = "SAMPLED";
      })(dn = W.TraceFlags || (W.TraceFlags = {}));
    });
    var Ne = i((O) => {
      "use strict";
      Object.defineProperty(O, "__esModule", { value: true });
      O.INVALID_SPAN_CONTEXT = O.INVALID_TRACEID = O.INVALID_SPANID = void 0;
      var pn = Ze();
      O.INVALID_SPANID = "0000000000000000";
      O.INVALID_TRACEID = "00000000000000000000000000000000";
      O.INVALID_SPAN_CONTEXT = { traceId: O.INVALID_TRACEID, spanId: O.INVALID_SPANID, traceFlags: pn.TraceFlags.NONE };
    });
    var Se = i((ye) => {
      "use strict";
      Object.defineProperty(ye, "__esModule", { value: true });
      ye.NonRecordingSpan = void 0;
      var fn = Ne(), et = class {
        constructor(e = fn.INVALID_SPAN_CONTEXT) {
          this._spanContext = e;
        }
        spanContext() {
          return this._spanContext;
        }
        setAttribute(e, r) {
          return this;
        }
        setAttributes(e) {
          return this;
        }
        addEvent(e, r) {
          return this;
        }
        setStatus(e) {
          return this;
        }
        updateName(e) {
          return this;
        }
        end(e) {
        }
        isRecording() {
          return false;
        }
        recordException(e, r) {
        }
      };
      ye.NonRecordingSpan = et;
    });
    var nt = i((d) => {
      "use strict";
      Object.defineProperty(d, "__esModule", { value: true });
      d.getSpanContext = d.setSpanContext = d.deleteSpan = d.setSpan = d.getActiveSpan = d.getSpan = void 0;
      var On = k(), bn = Se(), vn = X(), tt = (0, On.createContextKey)("OpenTelemetry Context Key SPAN");
      function rt(t) {
        return t.getValue(tt) || void 0;
      }
      d.getSpan = rt;
      function Pn() {
        return rt(vn.ContextAPI.getInstance().active());
      }
      d.getActiveSpan = Pn;
      function Bt(t, e) {
        return t.setValue(tt, e);
      }
      d.setSpan = Bt;
      function En(t) {
        return t.deleteValue(tt);
      }
      d.deleteSpan = En;
      function Tn(t, e) {
        return Bt(t, new bn.NonRecordingSpan(e));
      }
      d.setSpanContext = Tn;
      function Nn(t) {
        var e;
        return (e = rt(t)) === null || e === void 0 ? void 0 : e.spanContext();
      }
      d.getSpanContext = Nn;
    });
    var Me = i((b) => {
      "use strict";
      Object.defineProperty(b, "__esModule", { value: true });
      b.wrapSpanContext = b.isSpanContextValid = b.isValidSpanId = b.isValidTraceId = void 0;
      var Ut = Ne(), yn = Se(), Sn = /^([0-9a-f]{32})$/i, Mn = /^[0-9a-f]{16}$/i;
      function Ft(t) {
        return Sn.test(t) && t !== Ut.INVALID_TRACEID;
      }
      b.isValidTraceId = Ft;
      function kt(t) {
        return Mn.test(t) && t !== Ut.INVALID_SPANID;
      }
      b.isValidSpanId = kt;
      function Rn(t) {
        return Ft(t.traceId) && kt(t.spanId);
      }
      b.isSpanContextValid = Rn;
      function Cn(t) {
        return new yn.NonRecordingSpan(t);
      }
      b.wrapSpanContext = Cn;
    });
    var st = i((Re) => {
      "use strict";
      Object.defineProperty(Re, "__esModule", { value: true });
      Re.NoopTracer = void 0;
      var An = X(), $t = nt(), at = Se(), In = Me(), ot = An.ContextAPI.getInstance(), it = class {
        startSpan(e, r, n = ot.active()) {
          if (!!(r != null && r.root))
            return new at.NonRecordingSpan();
          let s = n && (0, $t.getSpanContext)(n);
          return mn(s) && (0, In.isSpanContextValid)(s) ? new at.NonRecordingSpan(s) : new at.NonRecordingSpan();
        }
        startActiveSpan(e, r, n, a) {
          let s, u, _;
          if (arguments.length < 2)
            return;
          arguments.length === 2 ? _ = r : arguments.length === 3 ? (s = r, _ = n) : (s = r, u = n, _ = a);
          let l = u ?? ot.active(), p = this.startSpan(e, s, l), f = (0, $t.setSpan)(l, p);
          return ot.with(f, _, void 0, p);
        }
      };
      Re.NoopTracer = it;
      function mn(t) {
        return typeof t == "object" && typeof t.spanId == "string" && typeof t.traceId == "string" && typeof t.traceFlags == "number";
      }
    });
    var ut = i((Ce) => {
      "use strict";
      Object.defineProperty(Ce, "__esModule", { value: true });
      Ce.ProxyTracer = void 0;
      var hn = st(), xn = new hn.NoopTracer(), ct = class {
        constructor(e, r, n, a) {
          this._provider = e, this.name = r, this.version = n, this.options = a;
        }
        startSpan(e, r, n) {
          return this._getTracer().startSpan(e, r, n);
        }
        startActiveSpan(e, r, n, a) {
          let s = this._getTracer();
          return Reflect.apply(s.startActiveSpan, s, arguments);
        }
        _getTracer() {
          if (this._delegate)
            return this._delegate;
          let e = this._provider.getDelegateTracer(this.name, this.version, this.options);
          return e ? (this._delegate = e, this._delegate) : xn;
        }
      };
      Ce.ProxyTracer = ct;
    });
    var Kt = i((Ae) => {
      "use strict";
      Object.defineProperty(Ae, "__esModule", { value: true });
      Ae.NoopTracerProvider = void 0;
      var Dn = st(), lt = class {
        getTracer(e, r, n) {
          return new Dn.NoopTracer();
        }
      };
      Ae.NoopTracerProvider = lt;
    });
    var gt = i((Ie) => {
      "use strict";
      Object.defineProperty(Ie, "__esModule", { value: true });
      Ie.ProxyTracerProvider = void 0;
      var jn = ut(), Ln = Kt(), Vn = new Ln.NoopTracerProvider(), _t = class {
        getTracer(e, r, n) {
          var a;
          return (a = this.getDelegateTracer(e, r, n)) !== null && a !== void 0 ? a : new jn.ProxyTracer(this, e, r, n);
        }
        getDelegate() {
          var e;
          return (e = this._delegate) !== null && e !== void 0 ? e : Vn;
        }
        setDelegate(e) {
          this._delegate = e;
        }
        getDelegateTracer(e, r, n) {
          var a;
          return (a = this._delegate) === null || a === void 0 ? void 0 : a.getTracer(e, r, n);
        }
      };
      Ie.ProxyTracerProvider = _t;
    });
    var Xt = i((Y) => {
      "use strict";
      Object.defineProperty(Y, "__esModule", { value: true });
      Y.SamplingDecision = void 0;
      var wn;
      (function(t) {
        t[t.NOT_RECORD = 0] = "NOT_RECORD", t[t.RECORD = 1] = "RECORD", t[t.RECORD_AND_SAMPLED = 2] = "RECORD_AND_SAMPLED";
      })(wn = Y.SamplingDecision || (Y.SamplingDecision = {}));
    });
    var Wt = i((H) => {
      "use strict";
      Object.defineProperty(H, "__esModule", { value: true });
      H.SpanKind = void 0;
      var qn;
      (function(t) {
        t[t.INTERNAL = 0] = "INTERNAL", t[t.SERVER = 1] = "SERVER", t[t.CLIENT = 2] = "CLIENT", t[t.PRODUCER = 3] = "PRODUCER", t[t.CONSUMER = 4] = "CONSUMER";
      })(qn = H.SpanKind || (H.SpanKind = {}));
    });
    var Yt = i((z) => {
      "use strict";
      Object.defineProperty(z, "__esModule", { value: true });
      z.SpanStatusCode = void 0;
      var Gn;
      (function(t) {
        t[t.UNSET = 0] = "UNSET", t[t.OK = 1] = "OK", t[t.ERROR = 2] = "ERROR";
      })(Gn = z.SpanStatusCode || (z.SpanStatusCode = {}));
    });
    var Ht = i((j) => {
      "use strict";
      Object.defineProperty(j, "__esModule", { value: true });
      j.validateValue = j.validateKey = void 0;
      var dt = "[_0-9a-z-*/]", Bn = `[a-z]${dt}{0,255}`, Un = `[a-z0-9]${dt}{0,240}@[a-z]${dt}{0,13}`, Fn = new RegExp(`^(?:${Bn}|${Un})$`), kn = /^[ -~]{0,255}[!-~]$/, $n = /,|=/;
      function Kn(t) {
        return Fn.test(t);
      }
      j.validateKey = Kn;
      function Xn(t) {
        return kn.test(t) && !$n.test(t);
      }
      j.validateValue = Xn;
    });
    var er = i((me) => {
      "use strict";
      Object.defineProperty(me, "__esModule", { value: true });
      me.TraceStateImpl = void 0;
      var zt = Ht(), Qt = 32, Wn = 512, Jt = ",", Zt = "=", Q = class {
        constructor(e) {
          this._internalState = /* @__PURE__ */ new Map(), e && this._parse(e);
        }
        set(e, r) {
          let n = this._clone();
          return n._internalState.has(e) && n._internalState.delete(e), n._internalState.set(e, r), n;
        }
        unset(e) {
          let r = this._clone();
          return r._internalState.delete(e), r;
        }
        get(e) {
          return this._internalState.get(e);
        }
        serialize() {
          return this._keys().reduce((e, r) => (e.push(r + Zt + this.get(r)), e), []).join(Jt);
        }
        _parse(e) {
          e.length > Wn || (this._internalState = e.split(Jt).reverse().reduce((r, n) => {
            let a = n.trim(), s = a.indexOf(Zt);
            if (s !== -1) {
              let u = a.slice(0, s), _ = a.slice(s + 1, n.length);
              (0, zt.validateKey)(u) && (0, zt.validateValue)(_) && r.set(u, _);
            }
            return r;
          }, /* @__PURE__ */ new Map()), this._internalState.size > Qt && (this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, Qt))));
        }
        _keys() {
          return Array.from(this._internalState.keys()).reverse();
        }
        _clone() {
          let e = new Q();
          return e._internalState = new Map(this._internalState), e;
        }
      };
      me.TraceStateImpl = Q;
    });
    var tr = i((he) => {
      "use strict";
      Object.defineProperty(he, "__esModule", { value: true });
      he.createTraceState = void 0;
      var Yn = er();
      function Hn(t) {
        return new Yn.TraceStateImpl(t);
      }
      he.createTraceState = Hn;
    });
    var rr = i((xe) => {
      "use strict";
      Object.defineProperty(xe, "__esModule", { value: true });
      xe.context = void 0;
      var zn = X();
      xe.context = zn.ContextAPI.getInstance();
    });
    var nr = i((De) => {
      "use strict";
      Object.defineProperty(De, "__esModule", { value: true });
      De.diag = void 0;
      var Qn = M();
      De.diag = Qn.DiagAPI.instance();
    });
    var ar = i((L) => {
      "use strict";
      Object.defineProperty(L, "__esModule", { value: true });
      L.NOOP_METER_PROVIDER = L.NoopMeterProvider = void 0;
      var Jn = Ye(), je = class {
        getMeter(e, r, n) {
          return Jn.NOOP_METER;
        }
      };
      L.NoopMeterProvider = je;
      L.NOOP_METER_PROVIDER = new je();
    });
    var ir = i((Le) => {
      "use strict";
      Object.defineProperty(Le, "__esModule", { value: true });
      Le.MetricsAPI = void 0;
      var Zn = ar(), pt = S(), or = M(), ft = "metrics", J = class {
        constructor() {
        }
        static getInstance() {
          return this._instance || (this._instance = new J()), this._instance;
        }
        setGlobalMeterProvider(e) {
          return (0, pt.registerGlobal)(ft, e, or.DiagAPI.instance());
        }
        getMeterProvider() {
          return (0, pt.getGlobal)(ft) || Zn.NOOP_METER_PROVIDER;
        }
        getMeter(e, r, n) {
          return this.getMeterProvider().getMeter(e, r, n);
        }
        disable() {
          (0, pt.unregisterGlobal)(ft, or.DiagAPI.instance());
        }
      };
      Le.MetricsAPI = J;
    });
    var sr = i((Ve) => {
      "use strict";
      Object.defineProperty(Ve, "__esModule", { value: true });
      Ve.metrics = void 0;
      var ea = ir();
      Ve.metrics = ea.MetricsAPI.getInstance();
    });
    var cr = i((we) => {
      "use strict";
      Object.defineProperty(we, "__esModule", { value: true });
      we.NoopTextMapPropagator = void 0;
      var Ot = class {
        inject(e, r) {
        }
        extract(e, r) {
          return e;
        }
        fields() {
          return [];
        }
      };
      we.NoopTextMapPropagator = Ot;
    });
    var lr = i((v) => {
      "use strict";
      Object.defineProperty(v, "__esModule", { value: true });
      v.deleteBaggage = v.setBaggage = v.getActiveBaggage = v.getBaggage = void 0;
      var ta = X(), ra = k(), bt = (0, ra.createContextKey)("OpenTelemetry Baggage Key");
      function ur(t) {
        return t.getValue(bt) || void 0;
      }
      v.getBaggage = ur;
      function na() {
        return ur(ta.ContextAPI.getInstance().active());
      }
      v.getActiveBaggage = na;
      function aa(t, e) {
        return t.setValue(bt, e);
      }
      v.setBaggage = aa;
      function oa(t) {
        return t.deleteValue(bt);
      }
      v.deleteBaggage = oa;
    });
    var dr = i((Ge) => {
      "use strict";
      Object.defineProperty(Ge, "__esModule", { value: true });
      Ge.PropagationAPI = void 0;
      var vt = S(), ia = cr(), _r = He(), qe = lr(), sa = Ke(), gr = M(), Pt = "propagation", ca = new ia.NoopTextMapPropagator(), Z = class {
        constructor() {
          this.createBaggage = sa.createBaggage, this.getBaggage = qe.getBaggage, this.getActiveBaggage = qe.getActiveBaggage, this.setBaggage = qe.setBaggage, this.deleteBaggage = qe.deleteBaggage;
        }
        static getInstance() {
          return this._instance || (this._instance = new Z()), this._instance;
        }
        setGlobalPropagator(e) {
          return (0, vt.registerGlobal)(Pt, e, gr.DiagAPI.instance());
        }
        inject(e, r, n = _r.defaultTextMapSetter) {
          return this._getGlobalPropagator().inject(e, r, n);
        }
        extract(e, r, n = _r.defaultTextMapGetter) {
          return this._getGlobalPropagator().extract(e, r, n);
        }
        fields() {
          return this._getGlobalPropagator().fields();
        }
        disable() {
          (0, vt.unregisterGlobal)(Pt, gr.DiagAPI.instance());
        }
        _getGlobalPropagator() {
          return (0, vt.getGlobal)(Pt) || ca;
        }
      };
      Ge.PropagationAPI = Z;
    });
    var pr = i((Be) => {
      "use strict";
      Object.defineProperty(Be, "__esModule", { value: true });
      Be.propagation = void 0;
      var ua = dr();
      Be.propagation = ua.PropagationAPI.getInstance();
    });
    var vr = i((Ue) => {
      "use strict";
      Object.defineProperty(Ue, "__esModule", { value: true });
      Ue.TraceAPI = void 0;
      var Et = S(), fr = gt(), Or = Me(), V = nt(), br = M(), Tt = "trace", ee = class {
        constructor() {
          this._proxyTracerProvider = new fr.ProxyTracerProvider(), this.wrapSpanContext = Or.wrapSpanContext, this.isSpanContextValid = Or.isSpanContextValid, this.deleteSpan = V.deleteSpan, this.getSpan = V.getSpan, this.getActiveSpan = V.getActiveSpan, this.getSpanContext = V.getSpanContext, this.setSpan = V.setSpan, this.setSpanContext = V.setSpanContext;
        }
        static getInstance() {
          return this._instance || (this._instance = new ee()), this._instance;
        }
        setGlobalTracerProvider(e) {
          let r = (0, Et.registerGlobal)(Tt, this._proxyTracerProvider, br.DiagAPI.instance());
          return r && this._proxyTracerProvider.setDelegate(e), r;
        }
        getTracerProvider() {
          return (0, Et.getGlobal)(Tt) || this._proxyTracerProvider;
        }
        getTracer(e, r) {
          return this.getTracerProvider().getTracer(e, r);
        }
        disable() {
          (0, Et.unregisterGlobal)(Tt, br.DiagAPI.instance()), this._proxyTracerProvider = new fr.ProxyTracerProvider();
        }
      };
      Ue.TraceAPI = ee;
    });
    var Pr = i((Fe) => {
      "use strict";
      Object.defineProperty(Fe, "__esModule", { value: true });
      Fe.trace = void 0;
      var la = vr();
      Fe.trace = la.TraceAPI.getInstance();
    });
    var Cr = i((o) => {
      "use strict";
      Object.defineProperty(o, "__esModule", { value: true });
      o.trace = o.propagation = o.metrics = o.diag = o.context = o.INVALID_SPAN_CONTEXT = o.INVALID_TRACEID = o.INVALID_SPANID = o.isValidSpanId = o.isValidTraceId = o.isSpanContextValid = o.createTraceState = o.TraceFlags = o.SpanStatusCode = o.SpanKind = o.SamplingDecision = o.ProxyTracerProvider = o.ProxyTracer = o.defaultTextMapSetter = o.defaultTextMapGetter = o.ValueType = o.createNoopMeter = o.DiagLogLevel = o.DiagConsoleLogger = o.ROOT_CONTEXT = o.createContextKey = o.baggageEntryMetadataFromString = void 0;
      var _a = Ke();
      Object.defineProperty(o, "baggageEntryMetadataFromString", { enumerable: true, get: function() {
        return _a.baggageEntryMetadataFromString;
      } });
      var Er = k();
      Object.defineProperty(o, "createContextKey", { enumerable: true, get: function() {
        return Er.createContextKey;
      } });
      Object.defineProperty(o, "ROOT_CONTEXT", { enumerable: true, get: function() {
        return Er.ROOT_CONTEXT;
      } });
      var ga = Vt();
      Object.defineProperty(o, "DiagConsoleLogger", { enumerable: true, get: function() {
        return ga.DiagConsoleLogger;
      } });
      var da = ie();
      Object.defineProperty(o, "DiagLogLevel", { enumerable: true, get: function() {
        return da.DiagLogLevel;
      } });
      var pa = Ye();
      Object.defineProperty(o, "createNoopMeter", { enumerable: true, get: function() {
        return pa.createNoopMeter;
      } });
      var fa = wt();
      Object.defineProperty(o, "ValueType", { enumerable: true, get: function() {
        return fa.ValueType;
      } });
      var Tr = He();
      Object.defineProperty(o, "defaultTextMapGetter", { enumerable: true, get: function() {
        return Tr.defaultTextMapGetter;
      } });
      Object.defineProperty(o, "defaultTextMapSetter", { enumerable: true, get: function() {
        return Tr.defaultTextMapSetter;
      } });
      var Oa = ut();
      Object.defineProperty(o, "ProxyTracer", { enumerable: true, get: function() {
        return Oa.ProxyTracer;
      } });
      var ba = gt();
      Object.defineProperty(o, "ProxyTracerProvider", { enumerable: true, get: function() {
        return ba.ProxyTracerProvider;
      } });
      var va = Xt();
      Object.defineProperty(o, "SamplingDecision", { enumerable: true, get: function() {
        return va.SamplingDecision;
      } });
      var Pa = Wt();
      Object.defineProperty(o, "SpanKind", { enumerable: true, get: function() {
        return Pa.SpanKind;
      } });
      var Ea = Yt();
      Object.defineProperty(o, "SpanStatusCode", { enumerable: true, get: function() {
        return Ea.SpanStatusCode;
      } });
      var Ta = Ze();
      Object.defineProperty(o, "TraceFlags", { enumerable: true, get: function() {
        return Ta.TraceFlags;
      } });
      var Na = tr();
      Object.defineProperty(o, "createTraceState", { enumerable: true, get: function() {
        return Na.createTraceState;
      } });
      var Nt = Me();
      Object.defineProperty(o, "isSpanContextValid", { enumerable: true, get: function() {
        return Nt.isSpanContextValid;
      } });
      Object.defineProperty(o, "isValidTraceId", { enumerable: true, get: function() {
        return Nt.isValidTraceId;
      } });
      Object.defineProperty(o, "isValidSpanId", { enumerable: true, get: function() {
        return Nt.isValidSpanId;
      } });
      var yt = Ne();
      Object.defineProperty(o, "INVALID_SPANID", { enumerable: true, get: function() {
        return yt.INVALID_SPANID;
      } });
      Object.defineProperty(o, "INVALID_TRACEID", { enumerable: true, get: function() {
        return yt.INVALID_TRACEID;
      } });
      Object.defineProperty(o, "INVALID_SPAN_CONTEXT", { enumerable: true, get: function() {
        return yt.INVALID_SPAN_CONTEXT;
      } });
      var Nr = rr();
      Object.defineProperty(o, "context", { enumerable: true, get: function() {
        return Nr.context;
      } });
      var yr = nr();
      Object.defineProperty(o, "diag", { enumerable: true, get: function() {
        return yr.diag;
      } });
      var Sr = sr();
      Object.defineProperty(o, "metrics", { enumerable: true, get: function() {
        return Sr.metrics;
      } });
      var Mr = pr();
      Object.defineProperty(o, "propagation", { enumerable: true, get: function() {
        return Mr.propagation;
      } });
      var Rr = Pr();
      Object.defineProperty(o, "trace", { enumerable: true, get: function() {
        return Rr.trace;
      } });
      o.default = { context: Nr.context, diag: yr.diag, metrics: Sr.metrics, propagation: Mr.propagation, trace: Rr.trace };
    });
    var Aa = {};
    jr(Aa, { lambdaWrapper: () => ya });
    module2.exports = Vr(Aa);
    var g = Lr(Cr());
    function te(t, e = "", r = {}) {
      if (e && typeof t == "object" && t !== null && Object.keys(t).length === 0)
        return r[e] = Array.isArray(t) ? [] : {}, r;
      e = e ? `${e}.` : "";
      for (let n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (typeof t[n] == "object" && t[n] !== null ? te(t[n], e + n, r) : r[e + n] = t[n]);
      return r;
    }
    function ya(t) {
      return async (e, r) => {
        let n = g.trace.getTracer("@baselime/baselime-lambda-wrapper", "1"), a = Ra(e);
        console.log(a);
        let s = n.startSpan(r.functionName, { attributes: te({ event: e, context: r, faas: { execution: r.awsRequestId, name: r.functionName, runtime: "nodejs", id: r.invokedFunctionArn }, cloud: { account: { id: r.invokedFunctionArn.split(":")[4] } } }) }, a), u = g.trace.setSpan(g.context.active(), s);
        try {
          let _ = await g.context.with(u, t, null, e, r);
          return s.setAttributes(te(_, "result")), s.end(), _;
        } catch (_) {
          let l = _;
          throw s.recordException(l), s.setAttributes(te({ name: l.name, message: l.message, stack: l.stack }, "error")), s.end(), _;
        } finally {
          baselimeLambdaFlush && (console.log("flushing"), baselimeLambdaFlush());
        }
      };
    }
    function Sa(t) {
      var e, r;
      return (e = t.requestContext) != null && e.apiId ? "api" : t.Records && ((r = t.Records[0]) == null ? void 0 : r.EventSource) === "aws:sns" ? "sns" : "unknown";
    }
    var Ar = { keys(t) {
      return Object.keys(t);
    }, get(t, e) {
      return t[e];
    } };
    var Ma = { keys(t) {
      return Object.keys(t);
    }, get(t, e) {
      var r;
      return (r = t[e]) == null ? void 0 : r.Value;
    } };
    function Ra(t) {
      var n;
      let e, r = Ca(t);
      return (n = g.trace.getSpan(r)) != null && n.spanContext() ? r : e || g.ROOT_CONTEXT;
    }
    function Ca(t) {
      switch (Sa(t)) {
        case "api":
          let e = t.headers || {};
          return g.propagation.extract(g.default.context.active(), e, Ar);
        case "sns":
          return console.log(t.Records[0].Sns.MessageAttributes), g.propagation.extract(g.default.context.active(), t.Records[0].Sns.MessageAttributes, Ma);
      }
      return g.propagation.extract(g.default.context.active(), {}, Ar);
    }
  }
});

// src/api.js
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_dynamodb = __toESM(require("aws-sdk/clients/dynamodb"));
var import_sns = __toESM(require("aws-sdk/clients/sns"));
var import_eventbridge = __toESM(require("aws-sdk/clients/eventbridge"));
var import_lambda_node_opentelemetry = __toESM(require_lambda_node_opentelemetry());
var dynamo = new import_dynamodb.default();
var sns = new import_sns.default();
var eventbridge = new import_eventbridge.default();
var handler = (0, import_lambda_node_opentelemetry.lambdaWrapper)(async (event) => {
  await sns.publish({ TopicArn: process.env.TOPIC_ARN, Message: "wow much payload" }).promise();
  await eventbridge.putEvents({
    Entries: [{
      Source: "baselime",
      Detail: "too many chickens"
    }]
  }).promise();
  const random = Math.random();
  if (random < 0.3) {
    const response2 = await dynamo.updateItem({
      TableName: "this-table-does-not-exist",
      ReturnValues: "ALL_NEW",
      Key: {
        id: {
          S: "test"
        }
      },
      UpdateExpression: "ADD #c :c",
      ExpressionAttributeNames: {
        "#c": "count"
      },
      ExpressionAttributeValues: {
        ":c": { N: "1" }
      }
    }).promise();
  }
  const response = await dynamo.updateItem({
    TableName: process.env.DB_NAME,
    ReturnValues: "ALL_NEW",
    Key: {
      id: {
        S: "test"
      }
    },
    UpdateExpression: "ADD #c :c",
    ExpressionAttributeNames: {
      "#c": "count"
    },
    ExpressionAttributeValues: {
      ":c": { N: "1" }
    }
  }).promise();
  return {
    statusCode: 200,
    body: JSON.stringify({
      data: response
    })
  };
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
